﻿# AI-Based Solar Panel Soiling Detection and Power Loss Prediction
> **Subtitle:** AI-powered solar-panel soiling analysis and power-generation loss estimation.

A full-stack deep learning application engineered for solar energy diagnostics. The system integrates **Swin Transformer V2** for semantic vision segmentation of panel dust/particulates and **PatchTST (Patch Time Series Transformer)** for forecasting operational photovoltaic power loss.

---

## Key Features

- **Dedicated User Authentication**: Separate `/signup` and `/login` pages, secure bcrypt password hashing, JWT bearer tokens, and route protection.
- **Swin Transformer V2 Vision Engine**: Shifted-Window Hierarchical Vision Transformer with FPN segmentation head for pixel-level soiling detection.
- **PatchTST Time-Series Model**: Channel-independent Patch Time Series Transformer tokenizing multi-variate operational sequences for accurate power loss forecasting.
- **Dynamic Output Estimation**: Computes $\text{Estimated Output} = \text{Rated Power} \times (1 - \text{Power Loss} / 100)$ dynamically in Watts.
- **Interactive Visual Comparison**: Tabbed and side-by-side view of Original Image, Preprocessed (256×256), and Swin V2 Alpha-Blended Soiling Overlay.
- **Real-Time Pipeline Stepper**: Live execution stage visualizer on `/analysis`.
- **Per-User SQLite History**: Stores every completed analysis per user with instant cached reloading.
- **Camera Snapshot Integration**: Browser WebRTC camera access with automatic fallback.
- **Future IoT Hardware Architecture**: Documented `ArduinoTelemetryService` schema ready for pyranometer, temperature, and current/voltage sensors.

---

## Tech Stack

| Layer | Technologies |
|---|---|
| **Frontend** | React 18, Vite, React Router v6, Axios, Recharts, Lucide Icons, Modern CSS3 |
| **Backend** | Python 3.11, FastAPI, Uvicorn, SQLAlchemy, SQLite, Pydantic v2 |
| **AI / Computer Vision** | PyTorch, timm (Swin Transformer V2), OpenCV, Pillow, NumPy, Pandas, Scikit-Learn |
| **Authentication** | Passlib (bcrypt), PyJWT (HS256) |

---

## Project Structure

```
solar-soiling-ai/
├── frontend/
│   ├── src/
│   │   ├── components/       # Navbar, Sidebar, ProtectedRoute, UploadBox, CameraModal, ResultCard, etc.
│   │   ├── pages/            # Login, Signup, Dashboard, Upload, Analysis, Results, History, About, Profile
│   │   ├── services/         # Axios API client, JWT Auth service
│   │   ├── context/          # React AuthContext
│   │   ├── styles/           # Global renewable energy theme CSS
│   │   ├── App.jsx           # Main routing with ProtectedRoute wrappers
│   │   └── main.jsx
│   ├── package.json
│   └── vite.config.js
│
├── backend/
│   ├── app/
│   │   ├── main.py           # FastAPI application root & static routes
│   │   ├── api/              # /api/auth, /api/analyze, /api/history, /api/models, /api/health
│   │   ├── models/           # SQLAlchemy User & Analysis models, Swin V2 and PatchTST architectures
│   │   ├── services/         # Preprocessing, Swin V2, Feature pipeline, PatchTST, Report generator
│   │   └── schemas/          # Pydantic v2 validation models
│   ├── training/             # PyTorch training pipelines and synthetic dataset generator
│   ├── models/               # swin_v2_soiling.pth, patchtst_power_loss.pth
│   ├── uploads/              # Raw user uploads
│   ├── outputs/              # Generated preprocessed and Swin V2 overlay images
│   ├── tests/                # Automated pytest suite
│   ├── requirements.txt
│   └── README.md
│
├── data/
│   ├── swin/                 # Training images and masks
│   └── patchtst/             # CSV operational time-series data
└── README.md
```

---

## Quick Start Guide

### Prerequisites
- **Python 3.10+** (with pip)
- **Node.js 18+** and **npm**

---

### Step 1: Start the Backend Server

```bash
# 1. Navigate to backend directory
cd backend

# 2. (Optional) Create and activate virtual environment
python -m venv venv
# On Windows:
venv\Scripts\activate
# On Linux/macOS:
source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. (Optional) Train initial model checkpoints
python training/generate_sample_data.py
python training/train_swin_v2.py
python training/train_patchtst.py

# 5. Start FastAPI server
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
- **Backend API:** `http://127.0.0.1:8000`
- **Interactive Swagger Docs:** `http://127.0.0.1:8000/docs`

---

### Step 2: Start the Frontend Application

```bash
# 1. In a new terminal, navigate to frontend
cd frontend

# 2. Install dependencies
npm install

# 3. Start Vite development server
npm run dev
```
- **Frontend URL:** `http://localhost:5173`

---

## Demonstration Workflow for Project Guide

1. **Open Application**: Open `http://localhost:5173` (Redirects automatically to `/login`).
2. **Sign Up**: Click "Sign Up", enter Full Name, Email, Password, and create account.
3. **Login**: Sign in with credentials $\to$ redirects to `/dashboard`.
4. **Home Dashboard**: View real-time statistics (Total Analyses, Avg Soiling, Avg Power Loss, Latest Output) and AI model status.
5. **Upload Image**: Click "Analyze Solar Panel", upload or capture a solar panel image, and configure rated power (e.g. 420 W).
6. **Inference Pipeline**: Click "Analyze Solar Panel" $\to$ watch live multi-stage pipeline on `/analysis`.
7. **Results Dashboard**:
   - Inspect **Swin Transformer V2 Soiling %** and **PatchTST Power Loss %**.
   - Review **Estimated Output (W)** vs **Rated Power (W)**.
   - Switch between **Original**, **Preprocessed**, and **Swin V2 Soiling Overlay** tabs.
   - View dynamic circular soiling gauge and diurnal power loss forecast charts.
   - Read dynamic AI technical diagnostic assessment and cleaning recommendation.
8. **Analysis History**: Navigate to `/history` to filter, search, and reload any previous analysis report.
9. **About Project**: View full academic documentation, architecture breakdown, and future IoT hardware scope.
10. **Profile & Logout**: View account statistics and log out securely.

---

## Future Hardware & IoT Architecture

```
                    ┌────────────────────────┐
                    │ Arduino / ESP32 Sensor │
                    │ Pyranometer (W/m²)     │
                    │ DHT22 Temp (°C)        │
                    │ INA219 Voltage/Current │
                    └───────────┬────────────┘
                                │ JSON / MQTT / HTTP
                                ▼
                    ┌────────────────────────┐
                    │ Backend Telemetry API  │
                    │ ArduinoTelemetryService│
                    └───────────┬────────────┘
                                │ 24-Step Sliding Sequence
                                ▼
                    ┌────────────────────────┐
                    │    PatchTST Model      │
                    │ Power Loss Prediction  │
                    └────────────────────────┘
```
