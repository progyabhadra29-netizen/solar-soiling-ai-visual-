﻿# Backend Service - AI Solar Panel Soiling & Power Loss Predictor

FastAPI backend with PyTorch neural inference for Swin Transformer V2 (Vision Segmentation) and PatchTST (Time Series Forecasting).

## Endpoints

| Method | Route | Description | Auth |
|---|---|---|---|
| `POST` | `/api/auth/signup` | Register new user account | Public |
| `POST` | `/api/auth/login` | Authenticate user & get JWT token | Public |
| `GET` | `/api/auth/me` | Get active user profile & statistics | Bearer Token |
| `POST` | `/api/auth/logout` | Terminate session | Bearer Token |
| `POST` | `/api/analyze` | Run Swin V2 + PatchTST AI inference | Bearer Token |
| `GET` | `/api/history` | Retrieve user analysis history | Bearer Token |
| `GET` | `/api/history/{id}` | Get complete cached analysis record | Bearer Token |
| `DELETE` | `/api/history/{id}` | Delete analysis record | Bearer Token |
| `GET` | `/api/models/status` | Model weights & hardware status | Public |
| `GET` | `/api/health` | Service health check | Public |

## Running Tests

```bash
pytest tests/test_api.py -v
```
