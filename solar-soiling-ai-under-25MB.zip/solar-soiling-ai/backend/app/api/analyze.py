import os
import json
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, status
from sqlalchemy.orm import Session
from app.models.database import get_db
from app.models.user import User
from app.models.analysis import Analysis
from app.schemas.analysis import AnalysisResponse, ModelMetadata, ImagePaths
from app.services.authentication import get_current_user
from app.services.preprocessing import validate_image_file, preprocess_solar_image
from app.services.soiling_detection import run_swin_v2_soiling_detection
from app.services.power_prediction import predict_power_loss_with_patchtst
from app.services.report_generator import generate_ai_analysis_report

router = APIRouter(prefix="/api", tags=["Analysis"])

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUTPUTS_DIR = os.path.join(BASE_DIR, "outputs")

@router.post("/analyze", response_model=AnalysisResponse)
async def analyze_solar_panel(
    image: UploadFile = File(...),
    rated_power: float = Form(420.0),
    irradiance: float = Form(1000.0),
    ambient_temp: float = Form(25.0),
    humidity: float = Form(45.0),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # 1. Validate Input
    if rated_power <= 0 or rated_power > 5000:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Rated power must be a positive value (e.g. 100W to 2000W)."
        )
        
    content = await image.read()
    if not validate_image_file(image.filename, content):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid image file. Please upload a valid JPG, JPEG, PNG, or WEBP image under 15MB."
        )
        
    try:
        # 2. Preprocess Image
        orig_pil, proc_pil, rgb_256, meta = preprocess_solar_image(content)
        
        # 3. Solar Panel Isolation & Swin V2 Multi-Class Contamination Segmentation
        soiling_res = run_swin_v2_soiling_detection(
            rgb_256=rgb_256,
            original_pil=orig_pil,
            output_dir=OUTPUTS_DIR
        )
        
        panel_detected = soiling_res["panel_detected"]
        panel_condition = soiling_res["panel_condition"]
        soiling_pct = soiling_res["soiling_percentage"]
        dust_pct = soiling_res["dust_coverage_pct"]
        foreign_pct = soiling_res["foreign_objects_pct"]
        severity = soiling_res["severity"]
        confidence = soiling_res["detection_confidence"]
        shadow_detected = soiling_res["shadow_detected"]
        rec_action = soiling_res["recommended_action"]
        contamination_detected = soiling_res["contamination_detected"]
        contamination_types = soiling_res["contamination_types"]
        
        # 4. PatchTST Power Loss Prediction
        power_res = predict_power_loss_with_patchtst(
            soiling_percentage=soiling_pct,
            rated_power=rated_power,
            irradiance=irradiance,
            ambient_temp=ambient_temp,
            humidity=humidity
        )
        
        # 5. Generate AI Inspection Summary
        report = generate_ai_analysis_report(
            soiling_pct=soiling_pct,
            power_loss_pct=power_res["power_loss_percentage"],
            rated_power=rated_power,
            output_power=power_res["estimated_power_after"],
            severity=severity,
            panel_condition=panel_condition,
            contamination_types=contamination_types,
            shadow_detected=shadow_detected,
            recommended_action=rec_action
        )
        
        # 6. Save in SQLite Database
        img_files = soiling_res["image_files"]
        model_status_label = (
            "Swin V2 + PatchTST (Trained Weights)" 
            if (soiling_res["weights_loaded"] and power_res["weights_loaded"])
            else "Swin V2 + PatchTST (Pipeline Calibrated)"
        )
        
        meta_dict = {
            "irradiance": irradiance,
            "ambient_temp": ambient_temp,
            "humidity": humidity,
            "panel_detected": panel_detected,
            "panel_condition": panel_condition,
            "contamination_detected": contamination_detected,
            "contamination_types": contamination_types,
            "dust_coverage_pct": dust_pct,
            "foreign_objects_pct": foreign_pct,
            "detection_confidence": confidence,
            "shadow_detected": shadow_detected,
            "recommended_action": rec_action,
            "recommendation": report["recommendation"],
            "daily_energy_loss_kwh": power_res["daily_energy_loss_kwh"]
        }
        
        db_analysis = Analysis(
            user_id=current_user.id,
            image_path=img_files["original"],
            processed_image_path=img_files["processed"],
            overlay_image_path=img_files["overlay"],
            soiling_percentage=soiling_pct,
            power_loss_percentage=power_res["power_loss_percentage"],
            rated_power=rated_power,
            estimated_power_before=power_res["estimated_power_before"],
            estimated_power_after=power_res["estimated_power_after"],
            severity=severity,
            model_status=model_status_label,
            analysis_summary=report["summary"],
            metadata_json=json.dumps(meta_dict)
        )
        db.add(db_analysis)
        db.commit()
        db.refresh(db_analysis)
        
        return AnalysisResponse(
            id=db_analysis.id,
            success=True,
            created_at=db_analysis.created_at,
            models=ModelMetadata(
                soiling="Swin Transformer V2",
                power_loss="PatchTST",
                swin_weights_loaded=soiling_res["weights_loaded"],
                patchtst_weights_loaded=power_res["weights_loaded"],
                mode=model_status_label
            ),
            panel_detected=panel_detected,
            panel_condition=panel_condition,
            contamination_detected=contamination_detected,
            contamination_types=contamination_types,
            soiling_percentage=soiling_pct,
            dust_coverage_pct=dust_pct,
            foreign_objects_pct=foreign_pct,
            soiling_severity=severity,
            detection_confidence=confidence,
            shadow_detected=shadow_detected,
            recommended_action=rec_action,
            power_loss_percentage=power_res["power_loss_percentage"],
            rated_power=rated_power,
            estimated_power_before=power_res["estimated_power_before"],
            estimated_power_after=power_res["estimated_power_after"],
            daily_energy_loss_kwh=power_res["daily_energy_loss_kwh"],
            recommendation=report["recommendation"],
            analysis_summary=report["summary"],
            images=ImagePaths(
                original=f"/outputs/{img_files['original']}",
                processed=f"/outputs/{img_files['processed']}",
                overlay=f"/outputs/{img_files['overlay']}"
            ),
            metadata=meta_dict
        )
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Inference pipeline execution error: {str(e)}"
        )