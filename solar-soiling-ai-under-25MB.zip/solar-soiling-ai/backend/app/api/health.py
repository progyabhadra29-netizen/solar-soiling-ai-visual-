﻿from fastapi import APIRouter
import datetime

router = APIRouter(prefix="/api", tags=["Health"])

@router.get("/health")
def health_check():
    return {
        "status": "online",
        "service": "AI Solar Soiling Detection & Power Loss API",
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "version": "2.0.0"
    }
