import os
import json
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.models.database import get_db
from app.models.user import User
from app.models.analysis import Analysis
from app.schemas.analysis import HistoryItemResponse, AnalysisResponse, ModelMetadata, ImagePaths
from app.services.authentication import get_current_user

router = APIRouter(prefix="/api/history", tags=["History"])

@router.get("", response_model=List[HistoryItemResponse])
@router.get("/", response_model=List[HistoryItemResponse], include_in_schema=False)
def get_user_history(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    analyses = (
        db.query(Analysis)
        .filter(Analysis.user_id == current_user.id)
        .order_by(Analysis.created_at.desc())
        .all()
    )
    
    result = []
    for item in analyses:
        panel_cond = "Clean"
        if item.metadata_json:
            try:
                m = json.loads(item.metadata_json)
                panel_cond = m.get("panel_condition", "Clean")
            except Exception:
                pass
        result.append(HistoryItemResponse(
            id=item.id,
            created_at=item.created_at,
            image_path=f"/outputs/{item.image_path}",
            processed_image_path=f"/outputs/{item.processed_image_path}",
            overlay_image_path=f"/outputs/{item.overlay_image_path}",
            panel_condition=panel_cond,
            soiling_percentage=item.soiling_percentage,
            power_loss_percentage=item.power_loss_percentage,
            rated_power=item.rated_power,
            estimated_power_before=item.estimated_power_before,
            estimated_power_after=item.estimated_power_after,
            severity=item.severity,
            model_status=item.model_status,
            analysis_summary=item.analysis_summary
        ))
    return result

@router.get("/{analysis_id}", response_model=AnalysisResponse)
def get_single_analysis(
    analysis_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    analysis = (
        db.query(Analysis)
        .filter(Analysis.id == analysis_id, Analysis.user_id == current_user.id)
        .first()
    )
    if not analysis:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Analysis record not found."
        )
        
    meta = {}
    recommendation = "No cleaning required"
    daily_energy_loss_kwh = 0.0
    panel_detected = True
    panel_condition = "Clean" if analysis.soiling_percentage <= 1.0 else "Contaminated"
    contamination_detected = analysis.soiling_percentage > 1.0
    contamination_types = ["Fine dust"] if contamination_detected else []
    dust_coverage_pct = analysis.soiling_percentage
    foreign_objects_pct = 0.0
    detection_confidence = 94.0
    shadow_detected = False
    recommended_action = "No cleaning required" if analysis.soiling_percentage <= 1.0 else "Cleaning recommended"
    
    if analysis.metadata_json:
        try:
            meta = json.loads(analysis.metadata_json)
            recommendation = meta.get("recommendation", recommendation)
            daily_energy_loss_kwh = meta.get("daily_energy_loss_kwh", 0.0)
            panel_detected = meta.get("panel_detected", panel_detected)
            panel_condition = meta.get("panel_condition", panel_condition)
            contamination_detected = meta.get("contamination_detected", contamination_detected)
            contamination_types = meta.get("contamination_types", contamination_types)
            dust_coverage_pct = meta.get("dust_coverage_pct", dust_coverage_pct)
            foreign_objects_pct = meta.get("foreign_objects_pct", foreign_objects_pct)
            detection_confidence = meta.get("detection_confidence", detection_confidence)
            shadow_detected = meta.get("shadow_detected", shadow_detected)
            recommended_action = meta.get("recommended_action", recommended_action)
        except Exception:
            pass
            
    return AnalysisResponse(
        id=analysis.id,
        success=True,
        created_at=analysis.created_at,
        models=ModelMetadata(
            soiling="Swin Transformer V2",
            power_loss="PatchTST",
            swin_weights_loaded="Trained" in analysis.model_status,
            patchtst_weights_loaded="Trained" in analysis.model_status,
            mode=analysis.model_status
        ),
        panel_detected=panel_detected,
        panel_condition=panel_condition,
        contamination_detected=contamination_detected,
        contamination_types=contamination_types,
        soiling_percentage=analysis.soiling_percentage,
        dust_coverage_pct=dust_coverage_pct,
        foreign_objects_pct=foreign_objects_pct,
        soiling_severity=analysis.severity,
        detection_confidence=detection_confidence,
        shadow_detected=shadow_detected,
        recommended_action=recommended_action,
        power_loss_percentage=analysis.power_loss_percentage,
        rated_power=analysis.rated_power,
        estimated_power_before=analysis.estimated_power_before,
        estimated_power_after=analysis.estimated_power_after,
        daily_energy_loss_kwh=daily_energy_loss_kwh,
        recommendation=recommendation,
        analysis_summary=analysis.analysis_summary or "",
        images=ImagePaths(
            original=f"/outputs/{analysis.image_path}",
            processed=f"/outputs/{analysis.processed_image_path}",
            overlay=f"/outputs/{analysis.overlay_image_path}"
        ),
        metadata=meta
    )

@router.delete("/{analysis_id}")
def delete_analysis(
    analysis_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    analysis = (
        db.query(Analysis)
        .filter(Analysis.id == analysis_id, Analysis.user_id == current_user.id)
        .first()
    )
    if not analysis:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Analysis record not found."
        )
        
    db.delete(analysis)
    db.commit()
    return {"success": True, "message": f"Analysis #{analysis_id} deleted."}