﻿import os
import torch
from fastapi import APIRouter
from app.schemas.analysis import ModelStatusResponse

router = APIRouter(prefix="/api/models", tags=["Models Telemetry"])

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
MODELS_DIR = os.path.join(BASE_DIR, "models")
SWIN_WEIGHTS = os.path.join(MODELS_DIR, "swin_v2_soiling.pth")
PATCHTST_WEIGHTS = os.path.join(MODELS_DIR, "patchtst_power_loss.pth")

@router.get("/status", response_model=ModelStatusResponse)
def get_models_status():
    swin_exists = os.path.exists(SWIN_WEIGHTS)
    patchtst_exists = os.path.exists(PATCHTST_WEIGHTS)
    
    device_name = "CUDA (NVIDIA GPU)" if torch.cuda.is_available() else "CPU"
    
    return ModelStatusResponse(
        backend_status="healthy",
        swin_v2={
            "name": "Swin Transformer V2",
            "task": "Solar Panel Soiling Segmentation",
            "weights_file": "swin_v2_soiling.pth",
            "weights_loaded": swin_exists,
            "resolution": "256x256 / 384x384",
            "architecture": "Hierarchical Vision Transformer with Shifted Windows + FPN Head"
        },
        patchtst={
            "name": "PatchTST",
            "task": "Time-Series Power Loss Prediction",
            "weights_file": "patchtst_power_loss.pth",
            "weights_loaded": patchtst_exists,
            "architecture": "Patch Time Series Transformer with Channel Independence",
            "sequence_window": "24 Steps (Multi-variate)"
        },
        device=device_name,
        weights_directory=MODELS_DIR,
        ready_for_inference=True
    )
