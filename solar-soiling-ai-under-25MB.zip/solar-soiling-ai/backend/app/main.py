﻿import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from app.models.database import init_db
from app.api import auth, analyze, history, models, health

# Initialize SQLite database tables
init_db()

app = FastAPI(
    title="AI-Based Solar Panel Soiling Detection and Power Loss Prediction",
    description="Full-stack AI inference engine for photovoltaic condition assessment using Swin Transformer V2 & PatchTST.",
    version="2.0.0"
)

# Enable CORS for React Vite frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTPUTS_DIR = os.path.join(BASE_DIR, "outputs")
UPLOADS_DIR = os.path.join(BASE_DIR, "uploads")
os.makedirs(OUTPUTS_DIR, exist_ok=True)
os.makedirs(UPLOADS_DIR, exist_ok=True)

# Mount outputs for static image rendering
app.mount("/outputs", StaticFiles(directory=OUTPUTS_DIR), name="outputs")

# Register API Routers
app.include_router(auth.router)
app.include_router(analyze.router)
app.include_router(history.router)
app.include_router(models.router)
app.include_router(health.router)

@app.get("/")
def root():
    return {
        "message": "AI-Based Solar Panel Soiling Detection & Power Loss Prediction Backend",
        "docs_url": "/docs",
        "status": "running"
    }
