﻿import datetime
from sqlalchemy import Column, Integer, Float, String, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.models.database import Base

class Analysis(Base):
    __tablename__ = "analyses"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    # Image file paths
    image_path = Column(String, nullable=False)
    processed_image_path = Column(String, nullable=False)
    overlay_image_path = Column(String, nullable=False)

    # Solar & Model Metrics
    soiling_percentage = Column(Float, nullable=False)
    power_loss_percentage = Column(Float, nullable=False)
    rated_power = Column(Float, nullable=False)  # in Watts
    estimated_power_before = Column(Float, nullable=False)  # in Watts (Clean condition)
    estimated_power_after = Column(Float, nullable=False)  # in Watts (Current soiled output)
    
    # Categorization and Diagnostics
    severity = Column(String, nullable=False)  # Very Low, Low, Moderate, High, Severe
    model_status = Column(String, nullable=False)  # e.g. "Swin V2 + PatchTST (Trained)" or "Demo Mode"
    analysis_summary = Column(Text, nullable=True)
    metadata_json = Column(Text, nullable=True)  # JSON formatted extra params (irradiance, temp, etc.)

    # Relationship
    user = relationship("User", back_populates="analyses")
