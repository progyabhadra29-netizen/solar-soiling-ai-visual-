﻿import os
import torch
import numpy as np
from app.models.patchtst.model import PatchTST

class PatchTSTInferencePipeline:
    def __init__(self, weights_path=None, seq_len=24, num_features=6, device=None):
        if device is None:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(device)
            
        self.seq_len = seq_len
        self.num_features = num_features
        self.model = PatchTST(seq_len=seq_len, patch_len=8, stride=4, num_features=num_features)
        self.weights_loaded = False
        self.weights_path = weights_path
        
        if weights_path and os.path.exists(weights_path):
            try:
                checkpoint = torch.load(weights_path, map_location=self.device)
                if "model_state_dict" in checkpoint:
                    self.model.load_state_dict(checkpoint["model_state_dict"])
                else:
                    self.model.load_state_dict(checkpoint)
                self.weights_loaded = True
                print(f"[PatchTST] Successfully loaded trained weights from {weights_path}")
            except Exception as e:
                print(f"[PatchTST] Notice: Could not load weights ({e}). Running in model architecture evaluation mode.")
                self.weights_loaded = False
        else:
            print(f"[PatchTST] Checkpoint not found at {weights_path}. Running with initialized PatchTST weights.")
            
        self.model.to(self.device)
        self.model.eval()

    def predict_power_loss(self, sequence_tensor_or_array):
        """
        Runs PatchTST time-series inference.
        Args:
            sequence_tensor_or_array: numpy array or torch Tensor of shape [1, seq_len, num_features]
        Returns:
            power_loss_percentage: float (0.0 to 100.0)
            trend_forecast: list of forecasted intermediate steps
        """
        if isinstance(sequence_tensor_or_array, np.ndarray):
            tensor = torch.from_numpy(sequence_tensor_or_array).float()
        else:
            tensor = sequence_tensor_or_array.float()
            
        if tensor.dim() == 2:
            tensor = tensor.unsqueeze(0)
            
        tensor = tensor.to(self.device)
        
        with torch.no_grad():
            output = self.model(tensor)
            pred_val = float(output.squeeze().cpu().numpy())
            
        # Ensure physically realistic bounds for solar power loss (0.0% to 95.0%)
        power_loss_percentage = round(float(np.clip(pred_val, 0.0, 95.0)), 2)
        
        return {
            "power_loss_percentage": power_loss_percentage,
            "weights_loaded": self.weights_loaded
        }
