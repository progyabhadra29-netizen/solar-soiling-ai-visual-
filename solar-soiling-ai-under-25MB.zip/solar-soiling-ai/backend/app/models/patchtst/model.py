﻿import math
import torch
import torch.nn as nn
import torch.nn.functional as F

class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe.unsqueeze(0))

    def forward(self, x):
        # x: [Batch * Channels, Num_Patches, d_model]
        return x + self.pe[:, :x.size(1), :]


class PatchTSTEncoderLayer(nn.Module):
    def __init__(self, d_model=64, n_heads=4, d_ff=128, dropout=0.1):
        super().__init__()
        self.self_attn = nn.MultiheadAttention(embed_dim=d_model, num_heads=n_heads, dropout=dropout, batch_first=True)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        
        self.ffn = nn.Sequential(
            nn.Linear(d_model, d_ff),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_ff, d_model),
            nn.Dropout(dropout)
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        # Self attention
        attn_out, _ = self.self_attn(x, x, x)
        x = self.norm1(x + self.dropout(attn_out))
        
        # Feed forward
        ffn_out = self.ffn(x)
        x = self.norm2(x + ffn_out)
        return x


class PatchTST(nn.Module):
    """
    PatchTST: Patch Time Series Transformer for Solar Power Loss Prediction.
    
    Key Innovations:
    1. Patching: Aggregates sub-series time steps into patches to capture localized semantic trends.
    2. Channel Independence: Treats each time-series feature channel independently through shared transformer.
    3. Transformer Backbone: Captures long-range dependencies across historical operational windows.
    4. Prediction Head: Maps patch representations directly to target power loss percentage.
    """
    def __init__(
        self,
        seq_len=24,         # Historical lookback window length (e.g. 24 steps)
        patch_len=8,        # Length of each sub-series patch
        stride=4,           # Patch sliding stride
        num_features=6,     # Features: [soiling_%, irradiance, ambient_temp, panel_temp, humidity, expected_power]
        d_model=64,         # Transformer hidden dimension
        n_heads=4,          # Multi-head attention heads
        e_layers=3,         # Number of Transformer encoder layers
        d_ff=128,           # Feed-forward expansion dimension
        dropout=0.1,
        target_dim=1        # Target output: Predicted Power Loss %
    ):
        super().__init__()
        self.seq_len = seq_len
        self.patch_len = patch_len
        self.stride = stride
        self.num_features = num_features
        self.d_model = d_model
        
        # Calculate number of patches
        # Padded so that last patch covers the end of sequence
        self.num_patches = (seq_len - patch_len) // stride + 1
        
        # Patch Projection layer (maps patch_len -> d_model)
        self.patch_proj = nn.Linear(patch_len, d_model)
        self.pos_encoding = PositionalEncoding(d_model)
        
        # Transformer Encoder Layers
        self.encoder_layers = nn.ModuleList([
            PatchTSTEncoderLayer(d_model=d_model, n_heads=n_heads, d_ff=d_ff, dropout=dropout)
            for _ in range(e_layers)
        ])
        
        # Flatten + Prediction Projection Head
        self.head = nn.Sequential(
            nn.Flatten(start_dim=1),
            nn.Linear(num_features * self.num_patches * d_model, 128),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(128, 32),
            nn.GELU(),
            nn.Linear(32, target_dim)
        )

    def forward(self, x):
        """
        Args:
            x: Tensor of shape [Batch, seq_len, num_features]
        Returns:
            out: Tensor of shape [Batch, target_dim] representing predicted Power Loss %
        """
        B, L, M = x.shape  # Batch, Sequence Length, Channels
        
        # Transpose to [Batch, Channels, seq_len]
        x = x.permute(0, 2, 1)
        
        # Unfold into patches: [Batch, Channels, num_patches, patch_len]
        patches = x.unfold(dimension=-1, size=self.patch_len, step=self.stride)
        
        # Reshape to treat channels as independent batches: [Batch * Channels, num_patches, patch_len]
        num_patches = patches.shape[2]
        patches = patches.contiguous().view(B * M, num_patches, self.patch_len)
        
        # Project patches to d_model: [B * M, num_patches, d_model]
        enc_in = self.patch_proj(patches)
        enc_in = self.pos_encoding(enc_in)
        
        # Pass through Transformer encoder layers
        enc_out = enc_in
        for layer in self.encoder_layers:
            enc_out = layer(enc_out)
            
        # Reshape back: [Batch, Channels, num_patches, d_model] -> [Batch, Channels * num_patches * d_model]
        enc_out = enc_out.view(B, M, num_patches, self.d_model)
        
        # Final prediction head
        pred = self.head(enc_out)
        return pred
