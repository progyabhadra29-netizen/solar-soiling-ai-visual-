﻿import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    import timm
    HAS_TIMM = True
except ImportError:
    HAS_TIMM = False


class ConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.GELU(),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.GELU()
        )

    def forward(self, x):
        return self.block(x)


class SwinV2Decoder(nn.Module):
    """
    Multi-scale Feature Fusion Decoder for Swin Transformer V2.
    Combines hierarchical feature stages from Swin V2 into high-resolution segmentation mask.
    """
    def __init__(self, encoder_channels=[96, 192, 384, 768], decoder_channels=128):
        super().__init__()
        c1, c2, c3, c4 = encoder_channels
        
        # Lateral 1x1 convs
        self.lat4 = nn.Conv2d(c4, decoder_channels, 1)
        self.lat3 = nn.Conv2d(c3, decoder_channels, 1)
        self.lat2 = nn.Conv2d(c2, decoder_channels, 1)
        self.lat1 = nn.Conv2d(c1, decoder_channels, 1)
        
        # Smooth convs
        self.smooth3 = ConvBlock(decoder_channels, decoder_channels)
        self.smooth2 = ConvBlock(decoder_channels, decoder_channels)
        self.smooth1 = ConvBlock(decoder_channels, decoder_channels)
        
        # Final prediction head
        self.final_conv = nn.Sequential(
            nn.Conv2d(decoder_channels, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.GELU(),
            nn.Conv2d(64, 1, kernel_size=1)
        )

    def forward(self, features, input_shape):
        # features are [f1 (1/4), f2 (1/8), f3 (1/16), f4 (1/32)]
        f1, f2, f3, f4 = features
        
        p4 = self.lat4(f4)
        
        p3 = self.lat3(f3) + F.interpolate(p4, size=f3.shape[-2:], mode="bilinear", align_corners=False)
        p3 = self.smooth3(p3)
        
        p2 = self.lat2(f2) + F.interpolate(p3, size=f2.shape[-2:], mode="bilinear", align_corners=False)
        p2 = self.smooth2(p2)
        
        p1 = self.lat1(f1) + F.interpolate(p2, size=f1.shape[-2:], mode="bilinear", align_corners=False)
        p1 = self.smooth1(p1)
        
        out = F.interpolate(p1, size=input_shape[-2:], mode="bilinear", align_corners=False)
        logits = self.final_conv(out)
        return logits


class SwinV2SoilingSegmentation(nn.Module):
    """
    Complete Swin Transformer V2 Solar Panel Soiling Segmentation Architecture.
    Uses Swin V2 hierarchical feature representation + FPN Decoder Head.
    """
    def __init__(self, backbone_name="swinv2_tiny_window16_256", pretrained=True):
        super().__init__()
        self.backbone_name = backbone_name
        self.encoder_channels = [96, 192, 384, 768]
        
        if HAS_TIMM:
            try:
                self.backbone = timm.create_model(
                    backbone_name,
                    pretrained=pretrained,
                    features_only=True
                )
                self.encoder_channels = self.backbone.feature_info.channels()
            except Exception as e:
                self.backbone = self._build_fallback_encoder()
        else:
            self.backbone = self._build_fallback_encoder()
            
        self.decoder = SwinV2Decoder(
            encoder_channels=self.encoder_channels,
            decoder_channels=128
        )

    def _build_fallback_encoder(self):
        return nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(3, 64, 3, stride=2, padding=1),
                nn.BatchNorm2d(64),
                nn.GELU(),
                nn.Conv2d(64, 96, 3, stride=2, padding=1),
                nn.BatchNorm2d(96),
                nn.GELU()
            ),
            nn.Sequential(
                nn.Conv2d(96, 192, 3, stride=2, padding=1),
                nn.BatchNorm2d(192),
                nn.GELU()
            ),
            nn.Sequential(
                nn.Conv2d(192, 384, 3, stride=2, padding=1),
                nn.BatchNorm2d(384),
                nn.GELU()
            ),
            nn.Sequential(
                nn.Conv2d(384, 768, 3, stride=2, padding=1),
                nn.BatchNorm2d(768),
                nn.GELU()
            )
        ])

    def forward(self, x):
        if hasattr(self.backbone, "forward_features"):
            raw_features = self.backbone(x)
        elif isinstance(self.backbone, nn.ModuleList):
            raw_features = []
            cur = x
            for block in self.backbone:
                cur = block(cur)
                raw_features.append(cur)
        else:
            raw_features = self.backbone(x)
            
        # Standardize features to NCHW [Batch, Channels, Height, Width]
        formatted = []
        for f in raw_features:
            if f.dim() == 4:
                # If shape is [B, H, W, C], permute to [B, C, H, W]
                if f.shape[1] != f.shape[-1] and (f.shape[1] == 64 or f.shape[1] == 32 or f.shape[1] == 16 or f.shape[1] == 8):
                    f = f.permute(0, 3, 1, 2).contiguous()
                formatted.append(f)
            else:
                formatted.append(f)
                
        logits = self.decoder(formatted, input_shape=x.shape)
        return logits
