from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List
from datetime import datetime

class ImagePaths(BaseModel):
    original: str
    processed: str
    overlay: str

class ModelMetadata(BaseModel):
    soiling: str = "Swin Transformer V2"
    power_loss: str = "PatchTST"
    swin_weights_loaded: bool = False
    patchtst_weights_loaded: bool = False
    mode: str = "Trained Pipeline"

class AnalysisResponse(BaseModel):
    id: int
    success: bool = True
    created_at: datetime
    models: ModelMetadata
    
    # Mandated Section 8 Report Fields:
    panel_detected: bool = True
    panel_condition: str = "Clean"  # Clean / Contaminated / Uncertain
    contamination_detected: bool = False
    contamination_types: List[str] = Field(default_factory=list)
    soiling_percentage: float = 0.0
    dust_coverage_pct: float = 0.0
    foreign_objects_pct: float = 0.0
    soiling_severity: str = "Clean"  # Clean, Low, Moderate, High, Severe
    detection_confidence: float = 95.0
    shadow_detected: bool = False
    recommended_action: str = "No cleaning required"  # No cleaning required, Inspection recommended, Cleaning recommended
    
    # Power Output
    power_loss_percentage: float = 0.0
    rated_power: float = 420.0
    estimated_power_before: float = 420.0
    estimated_power_after: float = 420.0
    daily_energy_loss_kwh: Optional[float] = 0.0
    
    # Reports & Media
    recommendation: str = "No cleaning required"
    analysis_summary: str = ""
    images: ImagePaths
    metadata: Optional[Dict[str, Any]] = None

    class Config:
        from_attributes = True

class HistoryItemResponse(BaseModel):
    id: int
    created_at: datetime
    image_path: str
    processed_image_path: str
    overlay_image_path: str
    panel_condition: Optional[str] = "Clean"
    soiling_percentage: float
    power_loss_percentage: float
    rated_power: float
    estimated_power_before: float
    estimated_power_after: float
    severity: str
    model_status: str
    analysis_summary: Optional[str] = None

    class Config:
        from_attributes = True

class ModelStatusResponse(BaseModel):
    backend_status: str = "healthy"
    swin_v2: Dict[str, Any]
    patchtst: Dict[str, Any]
    device: str
    weights_directory: str
    ready_for_inference: bool