﻿"""
Future Hardware & IoT Integration Architecture
Documented interface for Arduino / ESP32 real-time sensor ingestion.
"""
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class ArduinoTelemetryPacket(BaseModel):
    device_id: str
    timestamp: datetime = datetime.utcnow()
    irradiance_w_m2: float            # Photodiode / Pyranometer
    ambient_temperature_c: float     # DHT22 / BME280
    panel_temperature_c: float       # DS18B20 contact probe
    humidity_pct: float              # DHT22
    voltage_v: float                 # INA219 / Voltage Divider
    current_a: float                 # INA219 / Hall Effect Sensor
    measured_power_w: Optional[float] = None

class ArduinoTelemetryService:
    """
    Service ready for future Serial/MQTT/HTTP telemetry streaming.
    Ingests live sensor packets and directly pipes them into PatchTST inference buffer.
    """
    @staticmethod
    def process_telemetry_packet(packet: ArduinoTelemetryPacket):
        if packet.measured_power_w is None:
            packet.measured_power_w = round(packet.voltage_v * packet.current_a, 2)
        return {
            "status": "ready_for_patchtst_ingestion",
            "telemetry": packet.dict()
        }
