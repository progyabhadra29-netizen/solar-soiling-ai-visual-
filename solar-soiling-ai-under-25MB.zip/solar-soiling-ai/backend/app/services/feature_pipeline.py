﻿import numpy as np

def construct_patchtst_time_series_features(
    soiling_percentage: float,
    irradiance: float = 1000.0,       # Standard Test Condition (W/m^2)
    ambient_temp: float = 25.0,       # STC ambient temperature (deg C)
    panel_temp: float = None,         # PV cell temperature (deg C)
    humidity: float = 45.0,           # Relative Humidity (%)
    seq_len: int = 24
):
    """
    Prepares a calibrated multi-variate operational sequence window for PatchTST.
    Features: [soiling_percentage, irradiance, ambient_temp, panel_temp, humidity, expected_power]
    """
    if panel_temp is None:
        # NOCT empirical cell temperature model: T_cell = T_amb + (NOCT - 20) * (Irradiance / 800)
        panel_temp = round(ambient_temp + (45.0 - 20.0) * (irradiance / 800.0), 2)
        
    # Baseline expected standard cell power factor
    expected_power_factor = (irradiance / 1000.0) * (1.0 - 0.004 * (panel_temp - 25.0))
    expected_power_factor = max(0.0, expected_power_factor)
    
    # Generate temporal trajectory of previous hours leading to current observation
    # Simulates natural diurnal irradiance and dust accumulation drift
    sequence = np.zeros((seq_len, 6), dtype=np.float32)
    
    for i in range(seq_len):
        hour_fraction = (i + 1) / seq_len
        # Slight dust accumulation drift up to the current Swin V2 observed soiling %
        historical_soiling = max(0.0, soiling_percentage * (0.85 + 0.15 * hour_fraction))
        
        # Diurnal solar cycle curve
        time_factor = np.sin(np.pi * (hour_fraction * 0.7 + 0.15))
        step_irr = max(100.0, irradiance * (0.8 + 0.2 * time_factor))
        step_amb = ambient_temp + (2.0 * np.sin(2 * np.pi * hour_fraction))
        step_cell = step_amb + (25.0 * (step_irr / 800.0))
        step_hum = max(20.0, humidity - (5.0 * time_factor))
        step_exp = max(50.0, 420.0 * (step_irr / 1000.0) * (1.0 - 0.004 * (step_cell - 25.0)))
        
        sequence[i, 0] = historical_soiling
        sequence[i, 1] = step_irr
        sequence[i, 2] = step_amb
        sequence[i, 3] = step_cell
        sequence[i, 4] = step_hum
        sequence[i, 5] = step_exp

    # Ensure final step reflects exact current observation
    sequence[-1, 0] = soiling_percentage
    sequence[-1, 1] = irradiance
    sequence[-1, 2] = ambient_temp
    sequence[-1, 3] = panel_temp
    sequence[-1, 4] = humidity
    sequence[-1, 5] = 420.0 * expected_power_factor
    
    return sequence
