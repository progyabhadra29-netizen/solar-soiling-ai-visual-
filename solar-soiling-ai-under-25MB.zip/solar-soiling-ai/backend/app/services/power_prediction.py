import os
from app.models.patchtst.inference import PatchTSTInferencePipeline
from app.services.feature_pipeline import construct_patchtst_time_series_features

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
PATCHTST_WEIGHTS = os.path.join(BASE_DIR, "models", "patchtst_power_loss.pth")
patchtst_pipeline = PatchTSTInferencePipeline(weights_path=PATCHTST_WEIGHTS)

def predict_power_loss_with_patchtst(
    soiling_percentage: float,
    rated_power: float = 420.0,
    irradiance: float = 1000.0,
    ambient_temp: float = 25.0,
    humidity: float = 45.0
):
    """
    Coordinates PatchTST time-series feature ingestion and dynamically calculates power metrics.
    Strict Section 5 rule:
    If soiling percentage is 0.0% (Clean panel), power loss attributable to contamination is strictly 0.0%!
    """
    if soiling_percentage <= 0.0:
        return {
            "power_loss_percentage": 0.0,
            "rated_power": rated_power,
            "estimated_power_before": round(rated_power, 2),
            "estimated_power_after": round(rated_power, 2),
            "daily_energy_loss_kwh": 0.0,
            "weights_loaded": patchtst_pipeline.weights_loaded
        }

    seq_features = construct_patchtst_time_series_features(
        soiling_percentage=soiling_percentage,
        irradiance=irradiance,
        ambient_temp=ambient_temp,
        humidity=humidity
    )
    
    res = patchtst_pipeline.predict_power_loss(seq_features)
    raw_power_loss = res["power_loss_percentage"]
    
    # Physics optical bounds:
    # Under physical photovoltaic optics: Power Loss % is tightly coupled to surface obstruction
    # Power Loss cannot wildly exceed total soiling coverage on unshaded strings
    if not res["weights_loaded"] or raw_power_loss <= 0.1:
        calibrated_loss = round(float(soiling_percentage * 0.76 + 0.04 * (ambient_temp / 25.0)), 2)
        power_loss = min(95.0, max(0.0, calibrated_loss))
    else:
        # Scale to ensure physical coherence with soiling %
        expected_range_max = soiling_percentage * 1.35
        expected_range_min = soiling_percentage * 0.45
        power_loss = round(float(np_clip := max(expected_range_min, min(expected_range_max, raw_power_loss))), 2)
        
    estimated_power_before = round(rated_power, 2)
    estimated_power_after = round(rated_power * (1.0 - (power_loss / 100.0)), 2)
    daily_energy_loss_kwh = round(((estimated_power_before - estimated_power_after) * 5.5) / 1000.0, 3)
    
    return {
        "power_loss_percentage": power_loss,
        "rated_power": rated_power,
        "estimated_power_before": estimated_power_before,
        "estimated_power_after": estimated_power_after,
        "daily_energy_loss_kwh": daily_energy_loss_kwh,
        "weights_loaded": res["weights_loaded"]
    }