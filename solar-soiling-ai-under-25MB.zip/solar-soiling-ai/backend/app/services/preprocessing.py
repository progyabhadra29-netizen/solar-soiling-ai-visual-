﻿import os
import io
import uuid
import numpy as np
from PIL import Image, ImageOps, ImageEnhance
import cv2

ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}
MAX_FILE_SIZE = 15 * 1024 * 1024  # 15 MB

def validate_image_file(filename: str, content: bytes) -> bool:
    if not filename:
        return False
    ext = os.path.splitext(filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        return False
    if len(content) > MAX_FILE_SIZE or len(content) < 100:
        return False
    return True

def preprocess_solar_image(image_bytes: bytes, target_size=(256, 256)):
    """
    Validates, corrects orientation, normalizes, and filters the solar panel image.
    Returns:
        original_pil: PIL.Image of the original uploaded image (RGB)
        processed_pil: PIL.Image of preprocessed normalized image
        cv_img: OpenCV RGB numpy array for Swin V2 inference
        image_metadata: dict containing format, size, dimensions
    """
    # Load with PIL and handle EXIF rotation
    pil_img = Image.open(io.BytesIO(image_bytes))
    pil_img = ImageOps.exif_transpose(pil_img)
    pil_img = pil_img.convert("RGB")
    
    orig_w, orig_h = pil_img.size
    
    # Convert to OpenCV format (BGR)
    cv_bgr = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)
    
    # Bilateral filter to smooth specular glare while preserving fine dust/bird-drop edges
    filtered = cv2.bilateralFilter(cv_bgr, d=7, sigmaColor=50, sigmaSpace=50)
    
    # CLAHE (Contrast Limited Adaptive Histogram Equalization) on L channel in LAB color space
    lab = cv2.cvtColor(filtered, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    l_clahe = clahe.apply(l)
    lab_clahe = cv2.merge((l_clahe, a, b))
    enhanced_bgr = cv2.cvtColor(lab_clahe, cv2.COLOR_LAB2BGR)
    
    # Resize to model target resolution (256x256)
    resized_bgr = cv2.resize(enhanced_bgr, target_size, interpolation=cv2.INTER_AREA)
    resized_rgb = cv2.cvtColor(resized_bgr, cv2.COLOR_BGR2RGB)
    processed_pil = Image.fromarray(resized_rgb)
    
    metadata = {
        "original_width": orig_w,
        "original_height": orig_h,
        "aspect_ratio": round(orig_w / max(1, orig_h), 2),
        "target_size": list(target_size),
        "color_channels": 3
    }
    
    return pil_img, processed_pil, resized_rgb, metadata
