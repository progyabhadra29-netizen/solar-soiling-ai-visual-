def generate_ai_analysis_report(
    soiling_pct: float,
    power_loss_pct: float,
    rated_power: float,
    output_power: float,
    severity: str,
    panel_condition: str = "Clean",
    contamination_types: list = None,
    shadow_detected: bool = False,
    recommended_action: str = "No cleaning required"
) -> dict:
    """
    Generates structured AI diagnosis summary and actionable operational recommendations
    following Section 8 Solar Panel Inspection Report mandates.
    """
    types_str = ", ".join(contamination_types) if contamination_types else "None detected"
    
    if panel_condition == "Clean":
        summary = (
            f"Solar Panel Inspection Complete. Panel surface is validated CLEAN with 0.0% detectable soiling coverage. "
            f"{'Natural cast shadow detected without physical particulate deposition. ' if shadow_detected else ''}"
            f"Photovoltaic module is operating at peak rated performance ({rated_power:.0f} W expected). "
            f"No soiling-related power attenuation observed."
        )
    elif panel_condition == "Uncertain":
        summary = (
            "Solar Panel Inspection INCONCLUSIVE: The system could not delineate solar panel boundaries with sufficient confidence. "
            "Image may be obstructed, blurry, or captured at an extreme angle without visible panel surfaces. "
            "Please upload a clearer image of the solar panel module."
        )
    else:
        summary = (
            f"Solar Panel Inspection Result: CONTAMINATED ({severity} severity tier). "
            f"Swin Transformer V2 surface isolation identified {soiling_pct:.1f}% contamination coverage on active cells. "
            f"Detected material types: {types_str}. "
            f"{'Cast shadows observed and separated from particulate count. ' if shadow_detected else ''}"
            f"PatchTST time-series forecasting predicts an estimated {power_loss_pct:.1f}% operational power loss. "
            f"Current estimated generation output is {output_power:.1f} W (Lost: {rated_power - output_power:.1f} W)."
        )
        
    return {
        "summary": summary,
        "recommendation": recommended_action
    }