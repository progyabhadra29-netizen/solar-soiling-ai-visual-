import os
import uuid
from PIL import Image
from app.models.swin_v2.inference import SwinV2InferencePipeline

# Initialize Singleton Pipeline
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SWIN_WEIGHTS = os.path.join(BASE_DIR, "models", "swin_v2_soiling.pth")
swin_pipeline = SwinV2InferencePipeline(weights_path=SWIN_WEIGHTS)

def run_swin_v2_soiling_detection(rgb_256, original_pil, output_dir):
    """
    Coordinates Swin V2 inference, panel isolation, contamination multi-class decomposition,
    and stores output inspection files.
    """
    os.makedirs(output_dir, exist_ok=True)
    result = swin_pipeline.predict(rgb_256, original_pil_image=original_pil)
    
    unique_id = uuid.uuid4().hex[:12]
    orig_name = f"orig_{unique_id}.jpg"
    proc_name = f"proc_{unique_id}.jpg"
    overlay_name = f"overlay_{unique_id}.jpg"
    
    orig_path = os.path.join(output_dir, orig_name)
    proc_path = os.path.join(output_dir, proc_name)
    overlay_path = os.path.join(output_dir, overlay_name)
    
    original_pil.save(orig_path, quality=92)
    Image.fromarray(rgb_256).save(proc_path, quality=90)
    result["overlay_pil"].save(overlay_path, quality=92)
    
    return {
        "panel_detected": result["panel_detected"],
        "panel_condition": result["panel_condition"],
        "contamination_detected": result["contamination_detected"],
        "contamination_types": result["contamination_types"],
        "soiling_percentage": result["soiling_percentage"],
        "dust_coverage_pct": result["dust_coverage_pct"],
        "foreign_objects_pct": result["foreign_objects_pct"],
        "severity": result["soiling_severity"],
        "detection_confidence": result["detection_confidence"],
        "shadow_detected": result["shadow_detected"],
        "recommended_action": result["recommended_action"],
        "weights_loaded": result["weights_loaded"],
        "image_files": {
            "original": orig_name,
            "processed": proc_name,
            "overlay": overlay_name
        }
    }