import os, sys, time, traceback, json
import numpy as np
import torch
import psutil

sys.path.insert(0, os.path.dirname(os.path.abspath(".")))
sys.path.insert(0, r"C:\Users\Pooja\.gemini\antigravity\scratch\solar-soiling-ai\backend")
os.chdir(r"C:\Users\Pooja\.gemini\antigravity\scratch\solar-soiling-ai\backend")

# ============================================================
# 1. MODEL PARAMETER COUNTS
# ============================================================
print("=" * 70)
print("SECTION 1: MODEL PARAMETER COUNTS")
print("=" * 70)

from app.models.swin_v2.model import SwinV2SoilingSegmentation
from app.models.patchtst.model import PatchTST

swin_model = SwinV2SoilingSegmentation(pretrained=False)
patchtst_model = PatchTST(seq_len=24, patch_len=8, stride=4, num_features=6)

swin_total = sum(p.numel() for p in swin_model.parameters())
swin_train = sum(p.numel() for p in swin_model.parameters() if p.requires_grad)
patchtst_total = sum(p.numel() for p in patchtst_model.parameters())
patchtst_train = sum(p.numel() for p in patchtst_model.parameters() if p.requires_grad)

print(f"Swin V2 Total Parameters:     {swin_total:>12,}")
print(f"Swin V2 Trainable Parameters: {swin_train:>12,}")
print(f"PatchTST Total Parameters:    {patchtst_total:>12,}")
print(f"PatchTST Trainable Parameters:{patchtst_train:>12,}")
print(f"Combined Total:               {swin_total + patchtst_total:>12,}")

# Model sizes on disk
swin_path = r"C:\Users\Pooja\.gemini\antigravity\scratch\solar-soiling-ai\backend\models\swin_v2_soiling.pth"
patchtst_path = r"C:\Users\Pooja\.gemini\antigravity\scratch\solar-soiling-ai\backend\models\patchtst_power_loss.pth"
swin_size_mb = os.path.getsize(swin_path) / (1024 * 1024) if os.path.exists(swin_path) else 0
patchtst_size_mb = os.path.getsize(patchtst_path) / (1024 * 1024) if os.path.exists(patchtst_path) else 0
print(f"Swin V2 Checkpoint Size:      {swin_size_mb:>10.2f} MB")
print(f"PatchTST Checkpoint Size:     {patchtst_size_mb:>10.2f} MB")

# ============================================================
# 2. INFERENCE TIMING
# ============================================================
print("\n" + "=" * 70)
print("SECTION 2: INFERENCE TIMING BENCHMARKS")
print("=" * 70)

device = torch.device("cpu")

# --- Swin V2 Segmentation Timing ---
swin_model.to(device).eval()
dummy_img = torch.randn(1, 3, 256, 256).to(device)

# Warmup
with torch.no_grad():
    for _ in range(3):
        _ = swin_model(dummy_img)

# Benchmark (10 runs)
swin_times = []
for _ in range(10):
    t0 = time.perf_counter()
    with torch.no_grad():
        _ = swin_model(dummy_img)
    swin_times.append(time.perf_counter() - t0)

swin_avg = np.mean(swin_times) * 1000
swin_std = np.std(swin_times) * 1000
print(f"Swin V2 Inference (avg 10 runs):  {swin_avg:.1f} +/- {swin_std:.1f} ms")

# --- PatchTST Timing ---
patchtst_model.to(device).eval()
dummy_seq = torch.randn(1, 24, 6).to(device)

with torch.no_grad():
    for _ in range(3):
        _ = patchtst_model(dummy_seq)

patchtst_times = []
for _ in range(10):
    t0 = time.perf_counter()
    with torch.no_grad():
        _ = patchtst_model(dummy_seq)
    patchtst_times.append(time.perf_counter() - t0)

patchtst_avg = np.mean(patchtst_times) * 1000
patchtst_std = np.std(patchtst_times) * 1000
print(f"PatchTST Inference (avg 10 runs): {patchtst_avg:.1f} +/- {patchtst_std:.1f} ms")

# ============================================================
# 3. MEMORY USAGE
# ============================================================
print("\n" + "=" * 70)
print("SECTION 3: MEMORY USAGE")
print("=" * 70)

process = psutil.Process(os.getpid())
mem_before = process.memory_info().rss / (1024 * 1024)

# Run both models
with torch.no_grad():
    _ = swin_model(dummy_img)
    _ = patchtst_model(dummy_seq)

mem_after = process.memory_info().rss / (1024 * 1024)
print(f"Process Memory Before Inference: {mem_before:.1f} MB")
print(f"Process Memory After Inference:  {mem_after:.1f} MB")
print(f"Peak CPU Memory During Inference: ~{mem_after:.0f} MB")

# ============================================================
# 4. END-TO-END API TIMING
# ============================================================
print("\n" + "=" * 70)
print("SECTION 4: END-TO-END /api/analyze RESPONSE TIME")
print("=" * 70)

import requests

BASE = "http://127.0.0.1:8000"

# Check if backend is running
try:
    h = requests.get(f"{BASE}/api/health", timeout=3)
    if h.status_code != 200:
        print("Backend not running. Starting measurement without API...")
        raise Exception("not running")

    # Login
    lr = requests.post(f"{BASE}/api/auth/login", json={"email": "test_debug@solar.ai", "password": "TestPass123!"})
    if lr.status_code != 200:
        lr = requests.post(f"{BASE}/api/auth/signup", json={"name": "Bench", "email": "bench@test.ai", "password": "BenchTest123!"})
        lr = requests.post(f"{BASE}/api/auth/login", json={"email": "bench@test.ai", "password": "BenchTest123!"})
    token = lr.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    img_path = r"C:\Users\Pooja\.gemini\antigravity\scratch\solar-soiling-ai\data\swin\images\solar_panel_001.jpg"
    
    e2e_times = []
    for i in range(5):
        with open(img_path, "rb") as f:
            files = {"image": ("test.jpg", f, "image/jpeg")}
            data = {"rated_power": 420.0, "irradiance": 1000.0, "ambient_temp": 25.0}
            t0 = time.perf_counter()
            r = requests.post(f"{BASE}/api/analyze", headers=headers, files=files, data=data)
            elapsed = time.perf_counter() - t0
            e2e_times.append(elapsed)

    e2e_avg = np.mean(e2e_times)
    e2e_std = np.std(e2e_times)
    print(f"End-to-end /api/analyze (avg 5 runs): {e2e_avg*1000:.0f} +/- {e2e_std*1000:.0f} ms ({e2e_avg:.2f} s)")

except Exception as e:
    print(f"API test skipped: {e}")

# ============================================================
# 5. SEGMENTATION METRICS (IoU, Precision, Recall, F1, Dice)
# ============================================================
print("\n" + "=" * 70)
print("SECTION 5: SEGMENTATION METRICS ON TEST SUBSET")
print("=" * 70)

from PIL import Image
import cv2

images_dir = r"C:\Users\Pooja\.gemini\antigravity\scratch\solar-soiling-ai\data\swin\images"
masks_dir = r"C:\Users\Pooja\.gemini\antigravity\scratch\solar-soiling-ai\data\swin\masks"

image_files = sorted([f for f in os.listdir(images_dir) if f.endswith(('.jpg', '.png'))])
mask_files = sorted([f for f in os.listdir(masks_dir) if f.endswith(('.jpg', '.png'))])

# Load weights
ckpt = torch.load(swin_path, map_location=device)
if "model_state_dict" in ckpt:
    swin_model.load_state_dict(ckpt["model_state_dict"])
else:
    swin_model.load_state_dict(ckpt)
swin_model.eval()

all_iou, all_dice, all_prec, all_rec, all_f1 = [], [], [], [], []
all_soiling_pcts_pred = []
all_soiling_pcts_gt = []

mean_in = np.array([0.485, 0.456, 0.406], dtype=np.float32)
std_in = np.array([0.229, 0.224, 0.225], dtype=np.float32)

for img_f, mask_f in zip(image_files, mask_files):
    # Load image
    img = Image.open(os.path.join(images_dir, img_f)).convert("RGB").resize((256, 256))
    img_np = np.array(img).astype(np.float32) / 255.0
    img_norm = (img_np - mean_in) / std_in
    tensor_i = torch.from_numpy(img_norm).permute(2, 0, 1).unsqueeze(0).float().to(device)

    # Load ground truth mask
    mask = Image.open(os.path.join(masks_dir, mask_f)).convert("L").resize((256, 256))
    gt = (np.array(mask) > 127).astype(np.float32)

    with torch.no_grad():
        logits = swin_model(tensor_i)
        probs = torch.sigmoid(logits).squeeze().cpu().numpy()
    
    pred = (probs >= 0.45).astype(np.float32)
    
    # Metrics
    tp = float(np.sum(pred * gt))
    fp = float(np.sum(pred * (1 - gt)))
    fn = float(np.sum((1 - pred) * gt))
    tn = float(np.sum((1 - pred) * (1 - gt)))
    
    iou = tp / max(1.0, tp + fp + fn)
    dice = (2 * tp) / max(1.0, 2 * tp + fp + fn)
    prec = tp / max(1.0, tp + fp)
    rec = tp / max(1.0, tp + fn)
    f1 = (2 * prec * rec) / max(1e-8, prec + rec)
    
    all_iou.append(iou)
    all_dice.append(dice)
    all_prec.append(prec)
    all_rec.append(rec)
    all_f1.append(f1)
    
    # Soiling percentage error
    gt_pct = (np.sum(gt) / gt.size) * 100
    pred_pct = (np.sum(pred) / pred.size) * 100
    all_soiling_pcts_gt.append(gt_pct)
    all_soiling_pcts_pred.append(pred_pct)

print(f"Number of test images:       {len(image_files)}")
print(f"Mean IoU:                    {np.mean(all_iou):.4f}")
print(f"Mean Dice (F1-Seg):          {np.mean(all_dice):.4f}")
print(f"Mean Precision:              {np.mean(all_prec):.4f}")
print(f"Mean Recall:                 {np.mean(all_rec):.4f}")
print(f"Mean F1-Score:               {np.mean(all_f1):.4f}")

# Soiling percentage error
soiling_errors = [abs(p - g) for p, g in zip(all_soiling_pcts_pred, all_soiling_pcts_gt)]
print(f"\nMean Soiling % Error (MAE):  {np.mean(soiling_errors):.2f}%")
print(f"Max Soiling % Error:         {np.max(soiling_errors):.2f}%")
print(f"Mean GT Soiling %:           {np.mean(all_soiling_pcts_gt):.2f}%")
print(f"Mean Predicted Soiling %:    {np.mean(all_soiling_pcts_pred):.2f}%")

# ============================================================
# 6. PATCHTST FORECASTING METRICS (MAE, RMSE, R^2)
# ============================================================
print("\n" + "=" * 70)
print("SECTION 6: PATCHTST FORECASTING METRICS")
print("=" * 70)

import pandas as pd

csv_path = r"C:\Users\Pooja\.gemini\antigravity\scratch\solar-soiling-ai\data\patchtst\power_timeseries.csv"
df = pd.read_csv(csv_path)

# Build sequences (same as training)
seq_len = 24
feature_cols = ["soiling_pct", "irradiance", "ambient_temp", "panel_temp", "humidity", "expected_power"]
target_col = "power_loss_pct"

data = df[feature_cols].values.astype(np.float32)
targets = df[target_col].values.astype(np.float32)

sequences = []
labels = []
for i in range(len(data) - seq_len):
    sequences.append(data[i:i+seq_len])
    labels.append(targets[i + seq_len - 1])

X = np.array(sequences)
y = np.array(labels)

# Use last 20% as test
split = int(0.8 * len(X))
X_test = torch.from_numpy(X[split:]).float().to(device)
y_test = y[split:]

# Load trained PatchTST
patchtst_ckpt = torch.load(patchtst_path, map_location=device)
if "model_state_dict" in patchtst_ckpt:
    patchtst_model.load_state_dict(patchtst_ckpt["model_state_dict"])
else:
    patchtst_model.load_state_dict(patchtst_ckpt)
patchtst_model.eval()

preds = []
with torch.no_grad():
    for i in range(len(X_test)):
        inp = X_test[i:i+1]
        out = patchtst_model(inp)
        preds.append(float(out.squeeze().cpu().numpy()))

preds = np.array(preds)
y_test = np.array(y_test)

mae = np.mean(np.abs(preds - y_test))
mse = np.mean((preds - y_test) ** 2)
rmse = np.sqrt(mse)
ss_res = np.sum((y_test - preds) ** 2)
ss_tot = np.sum((y_test - np.mean(y_test)) ** 2)
r2 = 1.0 - (ss_res / max(ss_tot, 1e-8))

print(f"Test Samples:  {len(y_test)}")
print(f"MAE:           {mae:.4f}")
print(f"MSE:           {mse:.4f}")
print(f"RMSE:          {rmse:.4f}")
print(f"R-squared:     {r2:.4f}")
print(f"Mean GT Loss:  {np.mean(y_test):.2f}%")
print(f"Mean Pred Loss:{np.mean(preds):.2f}%")

# ============================================================
# 7. ABLATION: PatchTST WITHOUT soiling channel
# ============================================================
print("\n" + "=" * 70)
print("SECTION 7: ABLATION - PatchTST WITHOUT SOILING CHANNEL")
print("=" * 70)

# Zero out the soiling channel (index 0) and re-run
X_test_no_soil = X_test.clone()
X_test_no_soil[:, :, 0] = 0.0  # Remove soiling info

preds_no_soil = []
with torch.no_grad():
    for i in range(len(X_test_no_soil)):
        inp = X_test_no_soil[i:i+1]
        out = patchtst_model(inp)
        preds_no_soil.append(float(out.squeeze().cpu().numpy()))

preds_no_soil = np.array(preds_no_soil)
mae_no_soil = np.mean(np.abs(preds_no_soil - y_test))
rmse_no_soil = np.sqrt(np.mean((preds_no_soil - y_test) ** 2))
ss_res_ns = np.sum((y_test - preds_no_soil) ** 2)
r2_no_soil = 1.0 - (ss_res_ns / max(ss_tot, 1e-8))

print(f"Without Soiling Channel MAE:   {mae_no_soil:.4f}")
print(f"Without Soiling Channel RMSE:  {rmse_no_soil:.4f}")
print(f"Without Soiling Channel R2:    {r2_no_soil:.4f}")
print(f"Degradation MAE:  +{mae_no_soil - mae:.4f} ({((mae_no_soil-mae)/max(mae,1e-8))*100:.1f}%)")
print(f"Degradation RMSE: +{rmse_no_soil - rmse:.4f} ({((rmse_no_soil-rmse)/max(rmse,1e-8))*100:.1f}%)")

# ============================================================
# 8. SEVERITY AGREEMENT CHECK
# ============================================================
print("\n" + "=" * 70)
print("SECTION 8: SEVERITY TIER AGREEMENT")
print("=" * 70)

def severity(pct):
    if pct < 5: return "Very Low"
    elif pct < 15: return "Low"
    elif pct < 30: return "Moderate"
    elif pct < 50: return "High"
    else: return "Severe"

gt_severities = [severity(g) for g in all_soiling_pcts_gt]
pred_severities = [severity(p) for p in all_soiling_pcts_pred]
agree = sum(1 for g, p in zip(gt_severities, pred_severities) if g == p)
total = len(gt_severities)
print(f"Severity Agreement: {agree}/{total} ({agree/total*100:.1f}%)")

# Within 1 tier
tier_order = {"Very Low": 0, "Low": 1, "Moderate": 2, "High": 3, "Severe": 4}
within_one = sum(1 for g, p in zip(gt_severities, pred_severities)
                 if abs(tier_order[g] - tier_order[p]) <= 1)
print(f"Within 1 Severity Tier: {within_one}/{total} ({within_one/total*100:.1f}%)")

print("\n" + "=" * 70)
print("ALL BENCHMARKS COMPLETE")
print("=" * 70)