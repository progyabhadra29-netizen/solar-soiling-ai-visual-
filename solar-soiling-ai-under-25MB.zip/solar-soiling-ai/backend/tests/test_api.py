﻿import os
import io
import pytest
from fastapi.testclient import TestClient
from PIL import Image
import numpy as np

# Ensure working directory for imports
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.main import app
from app.models.database import Base, engine, SessionLocal
from app.models.user import User

client = TestClient(app)

@pytest.fixture(scope="module")
def test_user():
    # Setup test user in database
    unique_email = f"test_engineer_{np.random.randint(1000, 9999)}@solar.ai"
    signup_res = client.post("/api/auth/signup", json={
        "name": "Test Engineer",
        "email": unique_email,
        "password": "Password123!"
    })
    assert signup_res.status_code == 201
    
    login_res = client.post("/api/auth/login", json={
        "email": unique_email,
        "password": "Password123!"
    })
    assert login_res.status_code == 200
    token = login_res.json()["access_token"]
    return {"token": token, "email": unique_email}

def test_health_check():
    res = client.get("/api/health")
    assert res.status_code == 200
    assert res.json()["status"] == "online"

def test_models_status():
    res = client.get("/api/models/status")
    assert res.status_code == 200
    data = res.json()
    assert data["backend_status"] == "healthy"
    assert "Swin Transformer V2" in data["swin_v2"]["name"]
    assert "PatchTST" in data["patchtst"]["name"]

def test_user_me(test_user):
    headers = {"Authorization": f"Bearer {test_user['token']}"}
    res = client.get("/api/auth/me", headers=headers)
    assert res.status_code == 200
    assert res.json()["email"] == test_user["email"]

def test_solar_panel_analysis_pipeline(test_user):
    headers = {"Authorization": f"Bearer {test_user['token']}"}
    
    # Create a synthetic test solar image in memory
    img = Image.new("RGB", (300, 300), color=(20, 50, 100))
    img_byte_arr = io.BytesIO()
    img.save(img_byte_arr, format="JPEG")
    img_byte_arr.seek(0)
    
    files = {"image": ("test_panel.jpg", img_byte_arr, "image/jpeg")}
    data = {"rated_power": 420.0, "irradiance": 1000.0, "ambient_temp": 25.0}
    
    res = client.post("/api/analyze", headers=headers, files=files, data=data)
    assert res.status_code == 200
    result = res.json()
    
    assert result["success"] is True
    assert "soiling_percentage" in result
    assert "power_loss_percentage" in result
    assert result["rated_power"] == 420.0
    assert result["estimated_power_before"] == 420.0
    assert result["estimated_power_after"] <= 420.0
    assert "images" in result
    assert result["images"]["overlay"] is not None

def test_user_history(test_user):
    headers = {"Authorization": f"Bearer {test_user['token']}"}
    res = client.get("/api/history", headers=headers)
    assert res.status_code == 200
    data = res.json()
    assert isinstance(data, list)
    assert len(data) >= 1
