﻿import os
import glob
import torch
from torch.utils.data import Dataset
import numpy as np
import pandas as pd
from PIL import Image

class SolarSoilingDataset(Dataset):
    """
    PyTorch Dataset for Solar Panel Soiling Segmentation.
    Pairs solar panel RGB images with ground-truth binary soiling masks.
    """
    def __init__(self, images_dir, masks_dir, transform=None, target_size=(256, 256)):
        self.images_dir = images_dir
        self.masks_dir = masks_dir
        self.transform = transform
        self.target_size = target_size
        
        self.image_files = sorted(
            glob.glob(os.path.join(images_dir, "*.jpg")) + 
            glob.glob(os.path.join(images_dir, "*.png")) +
            glob.glob(os.path.join(images_dir, "*.jpeg"))
        )

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        img_path = self.image_files[idx]
        base_name = os.path.splitext(os.path.basename(img_path))[0]
        
        # Look for corresponding mask
        mask_path = os.path.join(self.masks_dir, f"{base_name}.png")
        if not os.path.exists(mask_path):
            mask_path = os.path.join(self.masks_dir, f"{base_name}_mask.png")
            
        img = Image.open(img_path).convert("RGB").resize(self.target_size)
        if os.path.exists(mask_path):
            mask = Image.open(mask_path).convert("L").resize(self.target_size)
            mask_np = (np.array(mask) > 128).astype(np.float32)
        else:
            # Synthetic mask fallback
            mask_np = np.zeros(self.target_size, dtype=np.float32)
            
        # ImageNet normalization
        img_np = np.array(img).astype(np.float32) / 255.0
        mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
        std = np.array([0.229, 0.224, 0.225], dtype=np.float32)
        img_np = (img_np - mean) / std
        
        img_tensor = torch.from_numpy(img_np).permute(2, 0, 1).float()
        mask_tensor = torch.from_numpy(mask_np).unsqueeze(0).float()
        
        return img_tensor, mask_tensor


class SolarTimeSeriesDataset(Dataset):
    """
    Sliding window dataset for PatchTST time-series power loss forecasting.
    """
    def __init__(self, csv_file, seq_len=24, feature_cols=None, target_col="power_loss_percentage"):
        self.df = pd.read_csv(csv_file)
        self.seq_len = seq_len
        
        if feature_cols is None:
            self.feature_cols = [
                "soiling_percentage", "irradiance", "ambient_temperature",
                "panel_temperature", "humidity", "expected_power"
            ]
        else:
            self.feature_cols = feature_cols
            
        self.target_col = target_col
        self.data_x = self.df[self.feature_cols].values.astype(np.float32)
        self.data_y = self.df[[self.target_col]].values.astype(np.float32)

    def __len__(self):
        return max(0, len(self.df) - self.seq_len)

    def __getitem__(self, idx):
        x = self.data_x[idx : idx + self.seq_len]
        y = self.data_y[idx + self.seq_len - 1]
        return torch.from_numpy(x).float(), torch.from_numpy(y).float()
