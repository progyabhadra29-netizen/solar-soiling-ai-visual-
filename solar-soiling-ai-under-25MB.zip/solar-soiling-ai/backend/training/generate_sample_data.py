﻿import os
import cv2
import numpy as np
import pandas as pd
from PIL import Image, ImageDraw

def generate_synthetic_solar_dataset(output_img_dir, output_mask_dir, num_samples=16):
    os.makedirs(output_img_dir, exist_ok=True)
    os.makedirs(output_mask_dir, exist_ok=True)
    
    print(f"Generating {num_samples} solar panel training images and masks...")
    
    for i in range(num_samples):
        # Base photovoltaic panel image (256x256)
        img = np.zeros((256, 256, 3), dtype=np.uint8)
        # Deep blue solar cell color (RGB: 15, 45, 90)
        img[:, :] = [18, 48, 96]
        
        # Grid lines (busbars and cell borders)
        for y in range(0, 256, 32):
            cv2.line(img, (0, y), (256, y), (220, 220, 230), 1)
        for x in range(0, 256, 32):
            cv2.line(img, (x, 0), (x, 256), (220, 220, 230), 1)
            
        # Soiling mask (0 = clean, 255 = soiled)
        mask = np.zeros((256, 256), dtype=np.uint8)
        
        # Add realistic dust patches / bird droppings / sand streaks
        num_patches = np.random.randint(2, 6)
        for _ in range(num_patches):
            cx = np.random.randint(30, 226)
            cy = np.random.randint(30, 226)
            rx = np.random.randint(15, 60)
            ry = np.random.randint(15, 60)
            angle = np.random.randint(0, 180)
            cv2.ellipse(mask, (cx, cy), (rx, ry), angle, 0, 360, 255, -1)
            
        # Blur mask to simulate natural particulate diffusion
        mask = cv2.GaussianBlur(mask, (15, 15), 0)
        
        # Overlay dust texture on the solar panel image
        dust_indices = mask > 50
        alpha = (mask[dust_indices].astype(np.float32) / 255.0)[:, np.newaxis]
        # Dust color: sandy brownish yellow (RGB: 180, 150, 100)
        dust_color = np.array([180, 150, 100], dtype=np.float32)
        
        img_dust = img.copy()
        blended = (1 - alpha * 0.75) * img[dust_indices] + (alpha * 0.75) * dust_color
        img_dust[dust_indices] = np.clip(blended, 0, 255).astype(np.uint8)
        
        # Save image and binary mask
        name = f"solar_panel_{i+1:03d}"
        cv2.imwrite(os.path.join(output_img_dir, f"{name}.jpg"), cv2.cvtColor(img_dust, cv2.COLOR_RGB2BGR))
        cv2.imwrite(os.path.join(output_mask_dir, f"{name}.png"), mask)
        
    print(f"Generated {num_samples} paired samples in {output_img_dir}")

def generate_synthetic_timeseries_dataset(output_csv_path, num_rows=400):
    os.makedirs(os.path.dirname(output_csv_path), exist_ok=True)
    print(f"Generating {num_rows} time-series steps for PatchTST training...")
    
    records = []
    base_soiling = 5.0
    
    for t in range(num_rows):
        # Accumulate soiling slowly over time with periodic rain clean events
        if t % 120 == 0:
            base_soiling = np.random.uniform(2.0, 6.0)
        else:
            base_soiling += np.random.uniform(0.05, 0.35)
            
        soiling_pct = round(min(85.0, base_soiling + np.random.normal(0, 0.5)), 2)
        
        # Diurnal solar cycle
        hour = (t % 24)
        if 6 <= hour <= 18:
            sun_angle = np.sin(np.pi * (hour - 6) / 12.0)
            irradiance = round(max(50.0, 950.0 * sun_angle + np.random.normal(0, 30)), 1)
            ambient_temp = round(20.0 + 12.0 * sun_angle + np.random.normal(0, 1.5), 1)
            panel_temp = round(ambient_temp + 22.0 * (irradiance / 800.0) + np.random.normal(0, 1.0), 1)
            humidity = round(max(20.0, 65.0 - 30.0 * sun_angle + np.random.normal(0, 3)), 1)
        else:
            irradiance = 0.0
            ambient_temp = round(16.0 + np.random.normal(0, 1.0), 1)
            panel_temp = ambient_temp
            humidity = round(75.0 + np.random.normal(0, 4), 1)
            
        rated_p = 420.0
        expected_power = round(rated_p * (irradiance / 1000.0) * max(0.0, 1.0 - 0.004 * (panel_temp - 25.0)), 1)
        
        # True power loss percentage: optical attenuation from soiling + thermal penalty
        optical_loss = soiling_pct * 0.82
        power_loss = round(min(90.0, max(0.0, optical_loss + np.random.normal(0, 0.8))), 2)
        
        records.append({
            "timestamp": f"2026-08-{(t // 24) + 1:02d} {hour:02d}:00:00",
            "soiling_percentage": soiling_pct,
            "irradiance": irradiance,
            "ambient_temperature": ambient_temp,
            "panel_temperature": panel_temp,
            "humidity": humidity,
            "expected_power": expected_power,
            "power_loss_percentage": power_loss
        })
        
    df = pd.DataFrame(records)
    df.to_csv(output_csv_path, index=False)
    print(f"Generated time-series dataset with {len(df)} rows at {output_csv_path}")

if __name__ == "__main__":
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    IMG_DIR = os.path.join(os.path.dirname(BASE_DIR), "data", "swin", "images")
    MASK_DIR = os.path.join(os.path.dirname(BASE_DIR), "data", "swin", "masks")
    CSV_PATH = os.path.join(os.path.dirname(BASE_DIR), "data", "patchtst", "power_timeseries.csv")
    
    generate_synthetic_solar_dataset(IMG_DIR, MASK_DIR, num_samples=20)
    generate_synthetic_timeseries_dataset(CSV_PATH, num_rows=300)
