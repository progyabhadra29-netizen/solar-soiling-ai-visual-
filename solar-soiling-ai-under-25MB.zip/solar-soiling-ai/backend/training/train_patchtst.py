﻿import os
import sys

# Ensure backend root is in sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, random_split
import numpy as np
from app.models.patchtst.model import PatchTST
from training.datasets import SolarTimeSeriesDataset

def train_patchtst(
    csv_path,
    output_weights_path,
    seq_len=24,
    epochs=5,
    batch_size=8,
    lr=1e-3
):
    print("=" * 60)
    print("  Training PatchTST for Solar Power Loss Prediction")
    print("=" * 60)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")
    
    if not os.path.exists(csv_path):
        print(f"Time-series dataset {csv_path} not found. Generate sample data first.")
        return
        
    dataset = SolarTimeSeriesDataset(csv_path, seq_len=seq_len)
    if len(dataset) == 0:
        print("Dataset contains insufficient time steps for sliding window.")
        return
        
    val_size = max(1, int(0.2 * len(dataset)))
    train_size = len(dataset) - val_size
    train_ds, val_ds = random_split(dataset, [train_size, val_size])
    
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)
    
    model = PatchTST(seq_len=seq_len, patch_len=8, stride=4, num_features=6).to(device)
    criterion = nn.MSELoss()
    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-3)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    
    best_loss = float("inf")
    
    for epoch in range(1, epochs + 1):
        model.train()
        train_loss = 0.0
        
        for seq, target in train_loader:
            seq = seq.to(device)
            target = target.to(device)
            
            optimizer.zero_grad()
            pred = model(seq)
            loss = criterion(pred, target)
            loss.backward()
            optimizer.step()
            train_loss += loss.item() * seq.size(0)
            
        train_loss /= len(train_ds)
        scheduler.step()
        
        # Validation
        model.eval()
        val_loss = 0.0
        val_mae = 0.0
        
        with torch.no_grad():
            for seq, target in val_loader:
                seq = seq.to(device)
                target = target.to(device)
                pred = model(seq)
                loss = criterion(pred, target)
                val_loss += loss.item() * seq.size(0)
                val_mae += torch.abs(pred - target).sum().item()
                
        val_loss /= len(val_ds)
        val_mae /= len(val_ds)
        val_rmse = np.sqrt(val_loss)
        
        print(f"Epoch [{epoch:02d}/{epochs:02d}] | Train MSE: {train_loss:.4f} | Val MSE: {val_loss:.4f} | MAE: {val_mae:.4f} | RMSE: {val_rmse:.4f}")
        
        if val_loss <= best_loss:
            best_loss = val_loss
            os.makedirs(os.path.dirname(output_weights_path), exist_ok=True)
            torch.save({
                "epoch": epoch,
                "model_state_dict": model.state_dict(),
                "optimizer_state_dict": optimizer.state_dict(),
                "val_loss": best_loss,
            }, output_weights_path)
            
    print(f"\n[DONE] Best checkpoint saved to {output_weights_path} with Val MSE: {best_loss:.4f}")

if __name__ == "__main__":
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    CSV_PATH = os.path.join(os.path.dirname(BASE_DIR), "data", "patchtst", "power_timeseries.csv")
    OUT_PATH = os.path.join(BASE_DIR, "models", "patchtst_power_loss.pth")
    
    train_patchtst(CSV_PATH, OUT_PATH, seq_len=24, epochs=5, batch_size=8)
