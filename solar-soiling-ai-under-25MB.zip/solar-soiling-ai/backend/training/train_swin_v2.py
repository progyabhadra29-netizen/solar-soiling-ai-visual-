﻿import os
import sys
import time

# Ensure backend root is in sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, random_split
from app.models.swin_v2.model import SwinV2SoilingSegmentation
from training.datasets import SolarSoilingDataset

class DiceBCELoss(nn.Module):
    def __init__(self, smooth=1e-5):
        super().__init__()
        self.smooth = smooth
        self.bce = nn.BCEWithLogitsLoss()

    def forward(self, logits, targets):
        bce_loss = self.bce(logits, targets)
        probs = torch.sigmoid(logits)
        intersection = (probs * targets).sum()
        dice = (2.0 * intersection + self.smooth) / (probs.sum() + targets.sum() + self.smooth)
        dice_loss = 1.0 - dice
        return bce_loss + dice_loss

def calculate_metrics(logits, targets):
    probs = torch.sigmoid(logits)
    preds = (probs >= 0.5).float()
    
    tp = (preds * targets).sum().item()
    fp = (preds * (1 - targets)).sum().item()
    fn = ((1 - preds) * targets).sum().item()
    tn = ((1 - preds) * (1 - targets)).sum().item()
    
    iou = tp / max(1.0, (tp + fp + fn))
    dice = (2.0 * tp) / max(1.0, (2.0 * tp + fp + fn))
    precision = tp / max(1.0, (tp + fp))
    recall = tp / max(1.0, (tp + fn))
    accuracy = (tp + tn) / max(1.0, (tp + tn + fp + fn))
    
    return {"iou": iou, "dice": dice, "precision": precision, "recall": recall, "accuracy": accuracy}

def train_swin_v2(
    images_dir,
    masks_dir,
    output_weights_path,
    epochs=5,
    batch_size=4,
    lr=1e-4
):
    print("=" * 60)
    print("  Training Swin Transformer V2 for Solar Soiling Detection")
    print("=" * 60)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")
    
    dataset = SolarSoilingDataset(images_dir, masks_dir)
    if len(dataset) == 0:
        print(f"No training images found in {images_dir}. Please generate sample data first.")
        return
        
    val_size = max(1, int(0.2 * len(dataset)))
    train_size = len(dataset) - val_size
    train_ds, val_ds = random_split(dataset, [train_size, val_size])
    
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)
    
    model = SwinV2SoilingSegmentation(pretrained=False).to(device)
    criterion = DiceBCELoss()
    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-2)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    
    best_iou = 0.0
    
    for epoch in range(1, epochs + 1):
        model.train()
        train_loss = 0.0
        
        for images, masks in train_loader:
            images = images.to(device)
            masks = masks.to(device)
            
            optimizer.zero_grad()
            logits = model(images)
            loss = criterion(logits, masks)
            loss.backward()
            optimizer.step()
            train_loss += loss.item() * images.size(0)
            
        train_loss /= len(train_ds)
        scheduler.step()
        
        # Validation
        model.eval()
        val_loss = 0.0
        val_metrics = {"iou": 0.0, "dice": 0.0, "precision": 0.0, "recall": 0.0, "accuracy": 0.0}
        
        with torch.no_grad():
            for images, masks in val_loader:
                images = images.to(device)
                masks = masks.to(device)
                logits = model(images)
                loss = criterion(logits, masks)
                val_loss += loss.item() * images.size(0)
                
                m = calculate_metrics(logits, masks)
                for k in val_metrics:
                    val_metrics[k] += m[k] * images.size(0)
                    
        val_loss /= len(val_ds)
        for k in val_metrics:
            val_metrics[k] /= len(val_ds)
            
        print(f"Epoch [{epoch:02d}/{epochs:02d}] | Train Loss: {train_loss:.4f} | Val Loss: {val_loss:.4f} | IoU: {val_metrics['iou']:.4f} | Dice: {val_metrics['dice']:.4f} | Acc: {val_metrics['accuracy']:.4f}")
        
        if val_metrics["iou"] >= best_iou or epoch == 1:
            best_iou = val_metrics["iou"]
            os.makedirs(os.path.dirname(output_weights_path), exist_ok=True)
            torch.save({
                "epoch": epoch,
                "model_state_dict": model.state_dict(),
                "optimizer_state_dict": optimizer.state_dict(),
                "best_iou": best_iou,
            }, output_weights_path)
            
    print(f"\n[DONE] Best checkpoint saved to {output_weights_path} with IoU: {best_iou:.4f}")

if __name__ == "__main__":
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    IMG_DIR = os.path.join(os.path.dirname(BASE_DIR), "data", "swin", "images")
    MASK_DIR = os.path.join(os.path.dirname(BASE_DIR), "data", "swin", "masks")
    OUT_PATH = os.path.join(BASE_DIR, "models", "swin_v2_soiling.pth")
    
    train_swin_v2(IMG_DIR, MASK_DIR, OUT_PATH, epochs=3, batch_size=4)
