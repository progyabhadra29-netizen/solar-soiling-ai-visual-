import requests
import json
import os

BASE_URL = "http://127.0.0.1:8000"

print("--- STEP 1: SIGN UP ---")
signup_payload = {
    "name": "Pooja Sharma",
    "email": "pooja.demo@solar.ai",
    "password": "SolarPassword123!"
}
res = requests.post(f"{BASE_URL}/api/auth/signup", json=signup_payload)
print(f"Signup Status: {res.status_code}")
if res.status_code not in (201, 400):
    print("Signup error:", res.text)

print("\n--- STEP 2: LOGIN ---")
login_payload = {
    "email": "pooja.demo@solar.ai",
    "password": "SolarPassword123!"
}
res = requests.post(f"{BASE_URL}/api/auth/login", json=login_payload)
print(f"Login Status: {res.status_code}")
assert res.status_code == 200, f"Login failed: {res.text}"
data = res.json()
token = data["access_token"]
headers = {"Authorization": f"Bearer {token}"}
print(f"Logged in user: {data['user']['name']} ({data['user']['email']})")

print("\n--- STEP 3: RUN AI PIPELINE INFERENCE (SWIN V2 + PATCHTST) ---")
test_img_path = r"C:\Users\Pooja\.gemini\antigravity\scratch\solar-soiling-ai\data\swin\images\solar_panel_001.jpg"
assert os.path.exists(test_img_path), f"Test image not found at {test_img_path}"

with open(test_img_path, "rb") as f:
    files = {"image": ("solar_panel_001.jpg", f, "image/jpeg")}
    form_data = {
        "rated_power": 450.0,
        "irradiance": 1000.0,
        "ambient_temp": 28.0,
        "humidity": 50.0
    }
    analyze_res = requests.post(f"{BASE_URL}/api/analyze", headers=headers, files=files, data=form_data)

print(f"Analyze Status: {analyze_res.status_code}")
assert analyze_res.status_code == 200, f"Analyze error: {analyze_res.text}"
analysis = analyze_res.json()

print(f"  • Analysis ID: #{analysis['id']}")
print(f"  • Swin Transformer V2 Soiling %: {analysis['soiling_percentage']}%")
print(f"  • Soiling Severity: {analysis['soiling_severity']}")
print(f"  • PatchTST Predicted Power Loss: {analysis['power_loss_percentage']}%")
print(f"  • Configured Rated Power: {analysis['rated_power']} W")
print(f"  • Estimated Current Output: {analysis['estimated_power_after']} W")
print(f"  • Overlay Image URL: {analysis['images']['overlay']}")
print(f"  • Dynamic AI Summary: {analysis['analysis_summary']}")
print(f"  • Maintenance Recommendation: {analysis['recommendation']}")

print("\n--- STEP 4: VERIFY USER HISTORY ---")
hist_res = requests.get(f"{BASE_URL}/api/history", headers=headers)
assert hist_res.status_code == 200
history = hist_res.json()
print(f"Total analyses in user history: {len(history)}")
assert len(history) >= 1
print(f"Latest record in history matches ID #{history[0]['id']} with severity '{history[0]['severity']}'")

print("\n--- STEP 5: VERIFY SINGLE RESULT RETRIEVAL ---")
single_res = requests.get(f"{BASE_URL}/api/history/{analysis['id']}", headers=headers)
assert single_res.status_code == 200
assert single_res.json()["id"] == analysis["id"]
print("Single result retrieved successfully from cache/database.")

print("\n=======================================================")
print("  ✓ ALL END-TO-END INFERENCE & AUTH WORKFLOWS PASSED! ")
print("=======================================================")