import React, { useRef, useState, useEffect } from "react";
import { Camera, X, RefreshCw, AlertTriangle } from "lucide-react";

export const CameraModal = ({ onCapture, onClose }) => {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [stream, setStream] = useState(null);
  const [error, setError] = useState(null);
  const [cameraReady, setCameraReady] = useState(false);

  useEffect(() => {
    let activeStream = null;

    const startCamera = async () => {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } }
        });
        activeStream = mediaStream;
        setStream(mediaStream);
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
          videoRef.current.onloadedmetadata = () => {
            videoRef.current.play();
            setCameraReady(true);
          };
        }
      } catch (err) {
        setError("Camera unavailable or permission denied. Please upload an image file instead.");
      }
    };

    startCamera();

    return () => {
      if (activeStream) {
        activeStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  const takeSnapshot = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob((blob) => {
      const dataUrl = canvas.toDataURL("image/jpeg");
      onCapture(blob, dataUrl);
    }, "image/jpeg", 0.95);
  };

  return (
    <div style={{
      position: "fixed",
      inset: 0,
      backgroundColor: "rgba(0, 0, 0, 0.85)",
      backdropFilter: "blur(8px)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      zIndex: 200,
      padding: "1rem"
    }}>
      <div className="solar-card" style={{ maxWidth: "640px", width: "100%", position: "relative" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
          <h3 style={{ display: "flex", alignItems: "center", gap: "0.5rem", fontSize: "1.2rem" }}>
            <Camera size={20} color="var(--solar-yellow)" /> Live Solar Camera Capture
          </h3>
          <button
            onClick={onClose}
            style={{ background: "transparent", border: "none", color: "var(--text-muted)", cursor: "pointer" }}
          >
            <X size={22} />
          </button>
        </div>

        {error ? (
          <div className="alert alert-danger" style={{ flexDirection: "column", alignItems: "flex-start", gap: "0.5rem" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
              <AlertTriangle size={20} />
              <strong>Camera Notice:</strong>
            </div>
            <p>{error}</p>
            <button className="btn btn-secondary" onClick={onClose} style={{ marginTop: "0.5rem" }}>
              Close & Upload File
            </button>
          </div>
        ) : (
          <div>
            <div style={{
              width: "100%",
              height: "360px",
              backgroundColor: "#000",
              borderRadius: "var(--radius-sm)",
              overflow: "hidden",
              position: "relative",
              display: "flex",
              alignItems: "center",
              justifyContent: "center"
            }}>
              <video
                ref={videoRef}
                playsInline
                muted
                style={{ width: "100%", height: "100%", objectFit: "cover" }}
              />
              {!cameraReady && (
                <div style={{ position: "absolute", color: "var(--solar-yellow)", textAlign: "center" }}>
                  <div className="spin-animation" style={{ fontSize: "2rem" }}>☀</div>
                  <p>Starting Camera Sensor...</p>
                </div>
              )}
            </div>

            <canvas ref={canvasRef} style={{ display: "none" }} />

            <div style={{ display: "flex", justifyContent: "flex-end", gap: "0.75rem", marginTop: "1.25rem" }}>
              <button type="button" className="btn btn-secondary" onClick={onClose}>
                Cancel
              </button>
              <button
                type="button"
                className="btn btn-primary"
                disabled={!cameraReady}
                onClick={takeSnapshot}
              >
                <Camera size={18} /> Capture Snapshot
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
