import React, { useState } from "react";
import { Eye, Layers, Sparkles, ShieldCheck } from "lucide-react";

export const ImageComparison = ({ images }) => {
  const [activeTab, setActiveTab] = useState("overlay");

  if (!images) return null;

  const views = [
    { id: "overlay", label: "Annotated Inspection Overlay", icon: <Sparkles size={16} />, src: images.overlay },
    { id: "processed", label: "Preprocessed & Normalized (256x256)", icon: <Layers size={16} />, src: images.processed },
    { id: "original", label: "Original Uploaded Image", icon: <Eye size={16} />, src: images.original },
  ];

  return (
    <div className="solar-card" style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "0.75rem" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
          <ShieldCheck size={20} color="var(--solar-yellow)" />
          <h3 style={{ fontSize: "1.1rem" }}>Visual Detection & Surface Overlay</h3>
        </div>

        {/* Tab Controls */}
        <div style={{
          display: "flex",
          backgroundColor: "var(--bg-input)",
          padding: "0.25rem",
          borderRadius: "var(--radius-sm)",
          border: "1px solid var(--border-color)"
        }}>
          {views.map((v) => (
            <button
              key={v.id}
              onClick={() => setActiveTab(v.id)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "0.4rem",
                padding: "0.5rem 0.9rem",
                fontSize: "0.82rem",
                fontWeight: activeTab === v.id ? 700 : 500,
                color: activeTab === v.id ? "#070d1e" : "var(--text-secondary)",
                backgroundColor: activeTab === v.id ? "var(--solar-yellow)" : "transparent",
                borderRadius: "6px",
                border: "none",
                cursor: "pointer",
                transition: "all 0.2s ease"
              }}
            >
              {v.icon}
              <span>{v.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Active Image Display */}
      <div style={{
        width: "100%",
        maxHeight: "450px",
        height: "380px",
        backgroundColor: "#f8fafc",
        borderRadius: "var(--radius-md)",
        overflow: "hidden",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        border: "1px solid var(--border-color)",
        position: "relative"
      }}>
        <img
          src={views.find((v) => v.id === activeTab)?.src}
          alt={activeTab}
          style={{ width: "100%", height: "100%", objectFit: "contain" }}
        />

        <div style={{
          position: "absolute",
          bottom: "1rem",
          left: "1rem",
          backgroundColor: "rgba(255, 255, 255, 0.95)",
          backdropFilter: "blur(8px)",
          padding: "0.4rem 0.8rem",
          borderRadius: "var(--radius-sm)",
          border: "1px solid var(--border-color)",
          boxShadow: "0 2px 8px rgba(0, 0, 0, 0.08)",
          fontSize: "0.8rem",
          color: "var(--text-primary)",
          fontWeight: 600,
          display: "flex",
          alignItems: "center",
          gap: "0.5rem"
        }}>
          <span>{views.find((v) => v.id === activeTab)?.label}</span>
        </div>

        {/* Legend Overlay for the Annotated tab */}
        {activeTab === "overlay" && (
          <div style={{
            position: "absolute",
            top: "1rem",
            right: "1rem",
            backgroundColor: "rgba(255, 255, 255, 0.96)",
            backdropFilter: "blur(8px)",
            padding: "0.6rem 0.9rem",
            borderRadius: "var(--radius-sm)",
            border: "1px solid var(--border-color)",
            boxShadow: "0 4px 12px rgba(0, 0, 0, 0.08)",
            fontSize: "0.75rem",
            display: "flex",
            flexDirection: "column",
            gap: "0.4rem"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
              <span style={{ width: "10px", height: "10px", borderRadius: "2px", backgroundColor: "#0284c7" }}></span>
              <span style={{ color: "var(--text-primary)", fontWeight: 500 }}>Panel Boundary</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
              <span style={{ width: "10px", height: "10px", borderRadius: "2px", backgroundColor: "var(--solar-yellow)" }}></span>
              <span style={{ color: "var(--text-primary)", fontWeight: 500 }}>Dust & Particulates</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
              <span style={{ width: "10px", height: "10px", borderRadius: "2px", backgroundColor: "#dc2626" }}></span>
              <span style={{ color: "var(--text-primary)", fontWeight: 500 }}>Leaves & Droppings</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
              <span style={{ width: "10px", height: "10px", borderRadius: "2px", backgroundColor: "#38bdf8" }}></span>
              <span style={{ color: "var(--text-primary)", fontWeight: 500 }}>Cast Shadow (Excluded)</span>
            </div>
          </div>
        )}
      </div>

      {/* Side-by-side Thumbnails for Quick Switching */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "0.75rem", marginTop: "0.5rem" }}>
        {views.map((v) => (
          <div
            key={v.id}
            onClick={() => setActiveTab(v.id)}
            style={{
              height: "90px",
              borderRadius: "var(--radius-sm)",
              overflow: "hidden",
              border: activeTab === v.id ? "2px solid var(--solar-yellow)" : "1px solid var(--border-color)",
              cursor: "pointer",
              position: "relative",
              backgroundColor: "#f1f5f9"
            }}
          >
            <img src={v.src} alt={v.label} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            <div style={{
              position: "absolute",
              bottom: 0,
              left: 0,
              right: 0,
              backgroundColor: "rgba(255, 255, 255, 0.92)",
              color: "var(--text-primary)",
              fontWeight: 600,
              fontSize: "0.7rem",
              padding: "0.2rem 0.4rem",
              textAlign: "center",
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis"
            }}>
              {v.label}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};