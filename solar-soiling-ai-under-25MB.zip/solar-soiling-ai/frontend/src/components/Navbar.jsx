import React, { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import api from "../services/api";
import { Sun, ShieldCheck, Cpu, User, LogOut, Activity, AlertCircle } from "lucide-react";

export const Navbar = ({ toggleSidebar }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [modelStatus, setModelStatus] = useState(null);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const res = await api.get("/api/models/status");
        setModelStatus(res.data);
      } catch (e) {
        setModelStatus({ backend_status: "offline" });
      }
    };
    fetchStatus();
  }, []);

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  return (
    <header style={{
      height: "var(--header-height)",
      background: "rgba(255, 255, 255, 0.95)",
      backdropFilter: "blur(12px)",
      borderBottom: "1px solid var(--border-color)",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "0 2rem",
      position: "sticky",
      top: 0,
      zIndex: 50
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
        <button 
          onClick={toggleSidebar}
          style={{
            background: "transparent",
            border: "none",
            color: "var(--text-secondary)",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            padding: "0.5rem"
          }}
          aria-label="Toggle Navigation"
        >
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
        </button>

        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
          <span style={{ fontSize: "0.85rem", color: "var(--text-muted)", display: "none" }} className="header-subtitle">
            AI-powered solar-panel soiling analysis and power loss estimation
          </span>
        </div>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: "1.25rem" }}>
        {/* Model Status Indicators */}
        <div style={{
          display: "flex",
          alignItems: "center",
          gap: "0.75rem",
          background: "#f1f5f9",
          padding: "0.4rem 0.8rem",
          borderRadius: "var(--radius-sm)",
          border: "1px solid var(--border-color)",
          fontSize: "0.8rem"
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: "0.35rem" }}>
            <span style={{
              width: "8px",
              height: "8px",
              borderRadius: "50%",
              backgroundColor: modelStatus?.backend_status === "healthy" ? "var(--solar-green)" : "var(--solar-red)",
              display: "inline-block",
              boxShadow: modelStatus?.backend_status === "healthy" ? "0 0 6px rgba(5, 150, 105, 0.4)" : "none"
            }} />
            <span style={{ color: "var(--text-secondary)", fontWeight: 500 }}>Backend: {modelStatus?.backend_status === "healthy" ? "Online" : "Offline"}</span>
          </div>

          <span style={{ color: "var(--border-color)" }}>|</span>

          <div style={{ display: "flex", alignItems: "center", gap: "0.35rem" }}>
            <Cpu size={14} color="var(--solar-yellow)" />
            <span style={{ color: "var(--text-secondary)", fontWeight: 500 }}>
              Swin V2 + PatchTST
            </span>
          </div>
        </div>

        {/* User Account / Profile dropdown */}
        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
          <Link to="/profile" style={{ display: "flex", alignItems: "center", gap: "0.5rem", color: "var(--text-primary)" }}>
            <div style={{
              width: "36px",
              height: "36px",
              borderRadius: "50%",
              background: "linear-gradient(135deg, #fef3c7, #fed7aa)",
              border: "1px solid var(--border-active)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontWeight: 700,
              color: "#b45309",
              fontSize: "0.9rem"
            }}>
              {user?.name ? user.name.charAt(0).toUpperCase() : "U"}
            </div>
            <div style={{ display: "flex", flexDirection: "column" }}>
              <span style={{ fontSize: "0.85rem", fontWeight: 600 }}>{user?.name || "Solar Engineer"}</span>
              <span style={{ fontSize: "0.7rem", color: "var(--text-muted)" }}>{user?.email}</span>
            </div>
          </Link>

          <button 
            onClick={handleLogout}
            title="Logout"
            style={{
              background: "#fee2e2",
              border: "1px solid #fecaca",
              color: "#dc2626",
              padding: "0.5rem",
              borderRadius: "var(--radius-sm)",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              transition: "all 0.2s ease"
            }}
          >
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </header>
  );
};
