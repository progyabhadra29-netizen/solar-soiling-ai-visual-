import React from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  LineChart,
  Line
} from "recharts";

export const PowerChart = ({ ratedPower, estimatedPower, powerLossPct }) => {
  const powerData = [
    {
      name: "Rated Output (Clean)",
      Power: ratedPower,
      fill: "#10b981"
    },
    {
      name: "Estimated Output (Soiled)",
      Power: estimatedPower,
      fill: "#f6c90e"
    },
    {
      name: "Predicted Power Loss",
      Power: ratedPower - estimatedPower,
      fill: "#ef4444"
    }
  ];

  // Simulated 24-step PatchTST operational lookahead curve
  const trendData = [];
  for (let i = 1; i <= 12; i++) {
    const baseHour = i + 6; // 7 AM to 6 PM
    const sunFactor = Math.sin(Math.PI * (i / 13));
    const ideal = Math.round(ratedPower * sunFactor);
    const soiled = Math.round(ideal * (1 - (powerLossPct / 100)));
    trendData.push({
      time: `${baseHour}:00`,
      Ideal: ideal,
      Estimated: soiled,
      Loss: ideal - soiled
    });
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>
      {/* Bar Comparison Chart */}
      <div className="solar-card">
        <h4 style={{ fontSize: "1rem", marginBottom: "1rem", color: "var(--text-primary)" }}>
          Photovoltaic Generation Comparison (Watts)
        </h4>
        <div style={{ width: "100%", height: "240px" }}>
          <ResponsiveContainer>
            <BarChart data={powerData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.05)" />
              <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} />
              <YAxis stroke="#94a3b8" fontSize={11} unit=" W" />
              <Tooltip 
                contentStyle={{ backgroundColor: "#0c1836", borderColor: "rgba(246, 201, 14, 0.3)", borderRadius: "8px" }}
                formatter={(val) => [`${val.toFixed(1)} W`, "Power"]}
              />
              <Bar dataKey="Power" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Diurnal Trend Line Chart */}
      <div className="solar-card">
        <h4 style={{ fontSize: "1rem", marginBottom: "1rem", color: "var(--text-primary)" }}>
          Diurnal Generation Forecast Curve (PatchTST Temporal Synthesis)
        </h4>
        <div style={{ width: "100%", height: "240px" }}>
          <ResponsiveContainer>
            <LineChart data={trendData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.05)" />
              <XAxis dataKey="time" stroke="#94a3b8" fontSize={11} />
              <YAxis stroke="#94a3b8" fontSize={11} unit=" W" />
              <Tooltip 
                contentStyle={{ backgroundColor: "#0c1836", borderColor: "rgba(246, 201, 14, 0.3)", borderRadius: "8px" }}
              />
              <Legend />
              <Line type="monotone" dataKey="Ideal" stroke="#10b981" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="Estimated" stroke="#f6c90e" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="Loss" stroke="#ef4444" strokeWidth={2} strokeDasharray="4 4" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
