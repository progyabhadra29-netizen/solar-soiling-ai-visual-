import React from "react";
import { CheckCircle2, Circle, Loader2 } from "lucide-react";

export const ProcessingSteps = ({ currentStep }) => {
  const steps = [
    { id: 1, label: "Image Uploaded", desc: "RGB solar panel input verified" },
    { id: 2, label: "Image Preprocessing", desc: "Bilateral filter, CLAHE & normalisation" },
    { id: 3, label: "Swin Transformer V2", desc: "Hierarchical Vision Transformer segmentation" },
    { id: 4, label: "Soiling Percentage Calculation", desc: "Pixel-level soiled area ratio estimation" },
    { id: 5, label: "Feature Window Preparation", desc: "Multi-variate operational temporal sequence" },
    { id: 6, label: "PatchTST Inference", desc: "Patch Time-Series Transformer power loss forecast" },
    { id: 7, label: "Generating Performance Report", desc: "Power output delta & cleaning recommendations" }
  ];

  return (
    <div className="solar-card" style={{ maxWidth: "600px", width: "100%", margin: "0 auto" }}>
      <h3 style={{ fontSize: "1.2rem", marginBottom: "1.5rem", display: "flex", alignItems: "center", gap: "0.5rem" }}>
        <span className="pulse-animation" style={{ color: "var(--solar-yellow)" }}>●</span> AI Inference Pipeline Live Status
      </h3>

      <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
        {steps.map((step) => {
          const isDone = currentStep > step.id;
          const isCurrent = currentStep === step.id;
          
          return (
            <div
              key={step.id}
              style={{
                display: "flex",
                alignItems: "flex-start",
                gap: "1rem",
                padding: "0.75rem",
                borderRadius: "var(--radius-sm)",
                backgroundColor: isCurrent ? "rgba(246, 201, 14, 0.08)" : "transparent",
                border: isCurrent ? "1px solid rgba(246, 201, 14, 0.3)" : "1px solid transparent",
                transition: "all 0.3s ease"
              }}
            >
              <div style={{ marginTop: "2px" }}>
                {isDone ? (
                  <CheckCircle2 size={20} color="var(--solar-green)" />
                ) : isCurrent ? (
                  <Loader2 size={20} className="spin-animation" color="var(--solar-yellow)" />
                ) : (
                  <Circle size={20} color="var(--text-muted)" />
                )}
              </div>

              <div>
                <div style={{
                  fontSize: "0.95rem",
                  fontWeight: isCurrent || isDone ? 700 : 500,
                  color: isCurrent ? "var(--solar-yellow)" : isDone ? "var(--text-primary)" : "var(--text-muted)"
                }}>
                  {step.label}
                </div>
                <div style={{ fontSize: "0.8rem", color: "var(--text-secondary)" }}>
                  {step.desc}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
