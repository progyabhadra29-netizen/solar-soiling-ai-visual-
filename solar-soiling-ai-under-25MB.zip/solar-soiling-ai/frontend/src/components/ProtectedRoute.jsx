import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div style={{ display: "flex", height: "100vh", alignItems: "center", justifyContent: "center", backgroundColor: "var(--bg-main)", color: "var(--solar-yellow)" }}>
        <div style={{ textAlign: "center" }}>
          <div className="spin-animation" style={{ fontSize: "2rem", marginBottom: "1rem" }}>☀</div>
          <p style={{ fontFamily: "Space Grotesk", fontSize: "1.1rem" }}>Authenticating Solar AI System...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
};
