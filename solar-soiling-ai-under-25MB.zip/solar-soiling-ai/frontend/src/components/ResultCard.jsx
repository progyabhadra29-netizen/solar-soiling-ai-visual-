import React from "react";

export const ResultCard = ({ title, value, unit, subtitle, icon, statusColor = "var(--solar-yellow)", badge }) => {
  return (
    <div className="solar-card" style={{ display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "0.75rem" }}>
        <span style={{ fontSize: "0.85rem", fontWeight: 600, color: "var(--text-secondary)", textTransform: "uppercase", letterSpacing: "0.05em" }}>
          {title}
        </span>
        <div style={{
          width: "36px",
          height: "36px",
          borderRadius: "8px",
          backgroundColor: `rgba(246, 201, 14, 0.1)`,
          border: `1px solid rgba(246, 201, 14, 0.2)`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: statusColor
        }}>
          {icon}
        </div>
      </div>

      <div style={{ display: "flex", alignItems: "baseline", gap: "0.35rem", margin: "0.25rem 0" }}>
        <span style={{ fontSize: "2rem", fontWeight: 800, fontFamily: "var(--font-heading)", color: "var(--text-primary)" }}>
          {value}
        </span>
        {unit && (
          <span style={{ fontSize: "1.1rem", fontWeight: 600, color: statusColor }}>
            {unit}
          </span>
        )}
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "0.5rem" }}>
        <span style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>
          {subtitle}
        </span>
        {badge && (
          <span className={`badge badge-${badge.toLowerCase().replace(" ", "-")}`}>
            {badge}
          </span>
        )}
      </div>
    </div>
  );
};
