import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { 
  Sun, 
  LayoutDashboard, 
  UploadCloud, 
  Cpu, 
  BarChart3, 
  History, 
  Info, 
  User, 
  LogOut 
} from "lucide-react";

export const Sidebar = ({ isOpen, closeSidebar }) => {
  const { logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  const navItems = [
    { to: "/dashboard", icon: <LayoutDashboard size={20} />, label: "Dashboard" },
    { to: "/upload", icon: <UploadCloud size={20} />, label: "Upload Image" },
    { to: "/analysis", icon: <Cpu size={20} />, label: "Analysis" },
    { to: "/results", icon: <BarChart3 size={20} />, label: "Results" },
    { to: "/history", icon: <History size={20} />, label: "Analysis History" },
    { to: "/about", icon: <Info size={20} />, label: "About Project" },
  ];

  return (
    <>
      {/* Backdrop for mobile */}
      {isOpen && (
        <div 
          onClick={closeSidebar}
          style={{
            position: "fixed",
            inset: 0,
            backgroundColor: "rgba(0, 0, 0, 0.6)",
            backdropFilter: "blur(4px)",
            zIndex: 90,
            display: "block"
          }}
        />
      )}

      <aside style={{
        width: "var(--sidebar-width)",
        backgroundColor: "#ffffff",
        borderRight: "1px solid var(--border-color)",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        height: "100vh",
        position: "sticky",
        top: 0,
        zIndex: 100,
        transition: "transform 0.3s ease",
        transform: isOpen ? "translateX(0)" : "translateX(0)"
      }}>
        <div>
          {/* Brand Header */}
          <div style={{
            padding: "1.5rem",
            display: "flex",
            alignItems: "center",
            gap: "0.75rem",
            borderBottom: "1px solid var(--border-color)"
          }}>
            <div style={{
              width: "40px",
              height: "40px",
              borderRadius: "10px",
              background: "linear-gradient(135deg, #f6c90e, #d97706)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 0 15px rgba(246, 201, 14, 0.4)"
            }}>
              <Sun size={24} color="#070d1e" />
            </div>
            <div>
              <h2 style={{ fontSize: "1.1rem", fontWeight: 800, color: "var(--text-primary)", lineHeight: 1.2 }}>
                Solar AI
              </h2>
              <span style={{ fontSize: "0.7rem", color: "var(--solar-yellow)", textTransform: "uppercase", letterSpacing: "0.08em", fontWeight: 600 }}>
                Swin V2 • PatchTST
              </span>
            </div>
          </div>

          {/* Navigation Links */}
          <nav style={{ padding: "1.25rem 0.75rem", display: "flex", flexDirection: "column", gap: "0.35rem" }}>
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={closeSidebar}
                style={({ isActive }) => ({
                  display: "flex",
                  alignItems: "center",
                  gap: "0.85rem",
                  padding: "0.8rem 1rem",
                  borderRadius: "var(--radius-sm)",
                  fontSize: "0.92rem",
                  fontWeight: isActive ? 700 : 500,
                  color: isActive ? "var(--solar-yellow)" : "var(--text-secondary)",
                  backgroundColor: isActive ? "rgba(217, 119, 6, 0.10)" : "transparent",
                  border: isActive ? "1px solid rgba(217, 119, 6, 0.25)" : "1px solid transparent",
                  transition: "all 0.2s ease"
                })}
              >
                {item.icon}
                <span>{item.label}</span>
              </NavLink>
            ))}
          </nav>
        </div>

        {/* Bottom Profile & Logout Links */}
        <div style={{ padding: "1.25rem 0.75rem", borderTop: "1px solid var(--border-color)", display: "flex", flexDirection: "column", gap: "0.35rem" }}>
          <NavLink
            to="/profile"
            onClick={closeSidebar}
            style={({ isActive }) => ({
              display: "flex",
              alignItems: "center",
              gap: "0.85rem",
              padding: "0.8rem 1rem",
              borderRadius: "var(--radius-sm)",
              fontSize: "0.92rem",
              fontWeight: isActive ? 700 : 500,
              color: isActive ? "var(--solar-yellow)" : "var(--text-secondary)",
              backgroundColor: isActive ? "rgba(217, 119, 6, 0.10)" : "transparent",
              border: isActive ? "1px solid rgba(217, 119, 6, 0.25)" : "1px solid transparent"
            })}
          >
            <User size={20} />
            <span>Profile</span>
          </NavLink>

          <button
            onClick={handleLogout}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "0.85rem",
              padding: "0.8rem 1rem",
              borderRadius: "var(--radius-sm)",
              fontSize: "0.92rem",
              fontWeight: 600,
              color: "#dc2626",
              backgroundColor: "transparent",
              border: "none",
              cursor: "pointer",
              width: "100%",
              textAlign: "left",
              fontFamily: "var(--font-main)"
            }}
          >
            <LogOut size={20} />
            <span>Logout</span>
          </button>
        </div>
      </aside>
    </>
  );
};
