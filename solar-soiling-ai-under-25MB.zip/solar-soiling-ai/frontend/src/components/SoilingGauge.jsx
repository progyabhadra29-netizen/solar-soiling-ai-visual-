import React from "react";

export const SoilingGauge = ({ percentage, severity }) => {
  const radius = 75;
  const strokeWidth = 14;
  const normalizedRadius = radius - strokeWidth * 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDashoffset = circumference - (Math.min(100, Math.max(0, percentage)) / 100) * circumference;

  const getColor = (pct) => {
    if (pct < 5) return "#10b981";
    if (pct < 15) return "#3b82f6";
    if (pct < 30) return "#f59e0b";
    if (pct < 50) return "#f97316";
    return "#ef4444";
  };

  const gaugeColor = getColor(percentage);

  return (
    <div className="solar-card" style={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center" }}>
      <h4 style={{ fontSize: "0.95rem", color: "var(--text-secondary)", marginBottom: "1rem", textTransform: "uppercase" }}>
        Swin Transformer V2 Soiling Gauge
      </h4>

      <div style={{ position: "relative", width: "160px", height: "160px", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <svg height={radius * 2} width={radius * 2} style={{ transform: "rotate(-90deg)" }}>
          <circle
            stroke="rgba(255, 255, 255, 0.08)"
            fill="transparent"
            strokeWidth={strokeWidth}
            r={normalizedRadius}
            cx={radius}
            cy={radius}
          />
          <circle
            stroke={gaugeColor}
            fill="transparent"
            strokeWidth={strokeWidth}
            strokeDasharray={`${circumference} ${circumference}`}
            style={{ strokeDashoffset, transition: "stroke-dashoffset 0.8s ease-in-out" }}
            strokeLinecap="round"
            r={normalizedRadius}
            cx={radius}
            cy={radius}
          />
        </svg>

        <div style={{ position: "absolute", display: "flex", flexDirection: "column", alignItems: "center" }}>
          <span style={{ fontSize: "1.8rem", fontWeight: 800, fontFamily: "var(--font-heading)", color: "var(--text-primary)" }}>
            {percentage.toFixed(1)}%
          </span>
          <span style={{ fontSize: "0.75rem", fontWeight: 700, color: gaugeColor, textTransform: "uppercase" }}>
            {severity}
          </span>
        </div>
      </div>

      <div style={{ marginTop: "1rem", fontSize: "0.82rem", color: "var(--text-muted)" }}>
        Calculated from pixel segmentation mask
      </div>
    </div>
  );
};
