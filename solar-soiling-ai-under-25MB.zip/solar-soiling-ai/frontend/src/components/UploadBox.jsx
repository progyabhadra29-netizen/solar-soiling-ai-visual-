import React, { useRef, useState } from "react";
import { Upload, Image as ImageIcon, Camera, CheckCircle2, AlertCircle } from "lucide-react";
import { CameraModal } from "./CameraModal";

export const UploadBox = ({ onImageSelect, selectedImage, ratedPower, setRatedPower }) => {
  const fileInputRef = useRef(null);
  const [dragActive, setDragActive] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [imageMeta, setImageMeta] = useState(null);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const processFile = (file) => {
    if (!file.type.match("image.*")) {
      alert("Please select a valid image file (PNG, JPG, JPEG, WEBP)");
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        setImageMeta({
          name: file.name,
          size: (file.size / (1024 * 1024)).toFixed(2) + " MB",
          dimensions: `${img.width} × ${img.height} px`,
          type: file.type
        });
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);

    onImageSelect(file);
  };

  const handleCameraCapture = (blob, dataUrl) => {
    const file = new File([blob], `camera_snapshot_${Date.now()}.jpg`, { type: "image/jpeg" });
    processFile(file);
    setShowCamera(false);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>
      {/* Drag and Drop Zone */}
      <div
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        onClick={() => !selectedImage && fileInputRef.current.click()}
        style={{
          border: `2px dashed ${dragActive ? "var(--solar-yellow)" : "var(--border-color)"}`,
          borderRadius: "var(--radius-md)",
          padding: "2.5rem 1.5rem",
          textAlign: "center",
          backgroundColor: dragActive ? "rgba(246, 201, 14, 0.05)" : "var(--bg-input)",
          cursor: selectedImage ? "default" : "pointer",
          transition: "all 0.25s ease",
          position: "relative",
          overflow: "hidden"
        }}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/png, image/jpeg, image/jpg, image/webp"
          onChange={handleChange}
          style={{ display: "none" }}
        />

        {selectedImage ? (
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "1rem" }}>
            <div style={{
              maxWidth: "360px",
              maxHeight: "260px",
              borderRadius: "var(--radius-sm)",
              overflow: "hidden",
              border: "2px solid var(--solar-yellow)",
              boxShadow: "0 0 20px rgba(246, 201, 14, 0.25)"
            }}>
              <img
                src={URL.createObjectURL(selectedImage)}
                alt="Selected solar panel preview"
                style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
              />
            </div>

            {imageMeta && (
              <div style={{
                display: "flex",
                flexWrap: "wrap",
                justifyContent: "center",
                gap: "1rem",
                fontSize: "0.85rem",
                color: "var(--text-secondary)",
                background: "#f1f5f9",
                padding: "0.5rem 1rem",
                borderRadius: "var(--radius-sm)",
                border: "1px solid var(--border-color)"
              }}>
                <span><strong>File:</strong> {imageMeta.name}</span>
                <span><strong>Size:</strong> {imageMeta.size}</span>
                <span><strong>Resolution:</strong> {imageMeta.dimensions}</span>
              </div>
            )}

            <div style={{ display: "flex", gap: "0.75rem", marginTop: "0.5rem" }}>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={(e) => {
                  e.stopPropagation();
                  fileInputRef.current.click();
                }}
              >
                Change Image
              </button>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowCamera(true);
                }}
              >
                <Camera size={16} /> Retake with Camera
              </button>
            </div>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "1rem" }}>
            <div style={{
              width: "64px",
              height: "64px",
              borderRadius: "50%",
              background: "rgba(246, 201, 14, 0.1)",
              border: "1px solid rgba(246, 201, 14, 0.3)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "var(--solar-yellow)"
            }}>
              <Upload size={32} />
            </div>

            <div>
              <h3 style={{ fontSize: "1.15rem", marginBottom: "0.25rem" }}>
                Drag & Drop Solar Panel Image
              </h3>
              <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>
                Supports high-resolution JPG, JPEG, PNG, WEBP (Max 15MB)
              </p>
            </div>

            <div style={{ display: "flex", gap: "0.75rem", marginTop: "0.5rem" }}>
              <button
                type="button"
                className="btn btn-primary"
                onClick={(e) => {
                  e.stopPropagation();
                  fileInputRef.current.click();
                }}
              >
                <ImageIcon size={18} /> Browse Image
              </button>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowCamera(true);
                }}
              >
                <Camera size={18} /> Capture Image
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Rated Power Configuration Card */}
      <div className="solar-card" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "1rem" }}>
        <div>
          <label className="form-label" style={{ marginBottom: "0.2rem" }}>
            Solar Panel Rated Power (STC)
          </label>
          <p style={{ fontSize: "0.85rem", color: "var(--text-muted)" }}>
            Standard manufacturer nameplate output rating in Watts.
          </p>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
          <input
            type="number"
            min="50"
            max="3000"
            step="10"
            value={ratedPower}
            onChange={(e) => setRatedPower(Number(e.target.value))}
            className="form-control"
            style={{ width: "120px", fontSize: "1.1rem", fontWeight: 700, textAlign: "center", color: "var(--solar-yellow)" }}
          />
          <span style={{ fontWeight: 700, color: "var(--text-secondary)", fontSize: "1.1rem" }}>Watts (W)</span>
        </div>
      </div>

      {/* Camera Capture Modal */}
      {showCamera && (
        <CameraModal
          onCapture={handleCameraCapture}
          onClose={() => setShowCamera(false)}
        />
      )}
    </div>
  );
};
