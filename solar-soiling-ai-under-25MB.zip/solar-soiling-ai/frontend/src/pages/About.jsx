import React from "react";
import { Link } from "react-router-dom";
import { 
  Sun, 
  Cpu, 
  Layers, 
  Activity, 
  Wifi, 
  Radio, 
  Database, 
  ArrowRight, 
  CheckCircle2, 
  Sparkles,
  Zap
} from "lucide-react";

export const About = () => {
  return (
    <div className="page-wrapper" style={{ display: "flex", flexDirection: "column", gap: "2.5rem", maxWidth: "1000px" }}>
      {/* Hero Header */}
      <div>
        <div className="badge badge-low" style={{ marginBottom: "0.5rem" }}>
          Academic Project Overview
        </div>
        <h1 style={{ fontSize: "2.4rem", marginBottom: "0.75rem" }}>
          AI-Based Solar Panel Soiling Detection & Power Loss Prediction
        </h1>
        <p style={{ fontSize: "1.1rem", color: "var(--text-secondary)", lineHeight: 1.6 }}>
          An end-to-end deep learning system designed for automated photovoltaic condition monitoring, dust accumulation segmentation, and operational generation loss estimation.
        </p>
      </div>

      {/* Problem & Solution Cards */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1.5rem" }} className="about-grid">
        <div className="solar-card" style={{ borderLeft: "4px solid var(--solar-orange)" }}>
          <h3 style={{ fontSize: "1.25rem", marginBottom: "0.75rem", color: "var(--solar-orange)" }}>
            The Problem: Photovoltaic Soiling Attenuation
          </h3>
          <p style={{ fontSize: "0.92rem", color: "var(--text-secondary)", lineHeight: 1.6 }}>
            Dust, sand, bird droppings, and environmental particulates accumulate continuously across solar panel glass surfaces. This particulate layer attenuates incoming solar irradiance, creates non-uniform shading hotspots, accelerates thermal degradation, and can cause significant energy generation losses ranging from <strong>10% to over 40%</strong>.
          </p>
        </div>

        <div className="solar-card" style={{ borderLeft: "4px solid var(--solar-green)" }}>
          <h3 style={{ fontSize: "1.25rem", marginBottom: "0.75rem", color: "var(--solar-green)" }}>
            The Proposed AI Solution
          </h3>
          <p style={{ fontSize: "0.92rem", color: "var(--text-secondary)", lineHeight: 1.6 }}>
            Our dual-stage AI architecture leverages <strong>Swin Transformer V2</strong> for pixel-level visual segmentation of dust coverage, extracts the precise soiling ratio, and streams the spatial metrics into <strong>PatchTST</strong> (Patch Time Series Transformer) along with environmental operational parameters to forecast dynamic power loss.
          </p>
        </div>
      </div>

      {/* AI Pipeline Flowchart */}
      <div className="solar-card">
        <h3 style={{ fontSize: "1.3rem", marginBottom: "1.5rem", display: "flex", alignItems: "center", gap: "0.5rem" }}>
          <Sparkles size={20} color="var(--solar-yellow)" /> End-to-End AI Inference Pipeline
        </h3>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "1rem" }}>
          {[
            { step: "01", title: "Solar Panel Image", desc: "RGB photo input from drone, camera, or operator" },
            { step: "02", title: "Image Preprocessing", desc: "Bilateral glare filter, CLAHE & ImageNet norm" },
            { step: "03", title: "Swin Transformer V2", desc: "Hierarchical Vision Transformer segmentation" },
            { step: "04", title: "Soiling % Calculation", desc: "Exact pixel ratio: (Soiled / Valid Pixels) * 100" },
            { step: "05", title: "Feature Preparation", desc: "Multi-variate operational sequence window" },
            { step: "06", title: "PatchTST Transformer", desc: "Patch-based channel-independent forecasting" },
            { step: "07", title: "Power Loss & Report", desc: "Rated power scaling and cleaning diagnosis" },
          ].map((item, idx) => (
            <div key={idx} style={{
              padding: "1rem",
              backgroundColor: "var(--bg-input)",
              borderRadius: "var(--radius-sm)",
              border: "1px solid var(--border-color)",
              position: "relative"
            }}>
              <span style={{ fontSize: "0.75rem", fontWeight: 800, color: "var(--solar-yellow)" }}>
                {item.step}
              </span>
              <h4 style={{ fontSize: "0.95rem", margin: "0.25rem 0", color: "var(--text-primary)" }}>
                {item.title}
              </h4>
              <p style={{ fontSize: "0.78rem", color: "var(--text-muted)", lineHeight: 1.4 }}>
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* AI Architecture Deep Dive */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1.5rem" }} className="about-grid">
        <div className="solar-card">
          <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "0.75rem" }}>
            <Cpu size={20} color="var(--solar-yellow)" />
            <h3 style={{ fontSize: "1.15rem" }}>Swin Transformer V2 Architecture</h3>
          </div>
          <ul style={{ paddingLeft: "1.2rem", fontSize: "0.88rem", color: "var(--text-secondary)", lineHeight: 1.7 }}>
            <li>Shifted Window Multi-Head Self-Attention (SW-MSA) limits computation to local windows while allowing cross-window connections.</li>
            <li>Hierarchical representation with 4 resolution stages (1/4, 1/8, 1/16, 1/32).</li>
            <li>Post-attention normalization (Res-Post-Norm) prevents divergence on high-resolution inputs.</li>
            <li>FPN Decoder fusion generates a 256×256 binary segmentation mask.</li>
          </ul>
        </div>

        <div className="solar-card">
          <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "0.75rem" }}>
            <Activity size={20} color="var(--solar-green)" />
            <h3 style={{ fontSize: "1.15rem" }}>PatchTST Architecture</h3>
          </div>
          <ul style={{ paddingLeft: "1.2rem", fontSize: "0.88rem", color: "var(--text-secondary)", lineHeight: 1.7 }}>
            <li>Sub-series patch extraction splits time-series sequence into patches of length P=8 with stride S=4.</li>
            <li>Channel-independence allows the model to process distinct sensor variables without interference.</li>
            <li>Transformer encoder captures multi-scale temporal correlations and diurnal solar cycles.</li>
            <li>MLP head outputs accurate operational power loss percentage.</li>
          </ul>
        </div>
      </div>

      {/* Future Scope & Hardware Architecture */}
      <div className="solar-card" style={{ border: "1px solid rgba(6, 182, 212, 0.3)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "0.6rem", marginBottom: "1rem" }}>
          <Wifi size={22} color="var(--solar-cyan)" />
          <h3 style={{ fontSize: "1.25rem" }}>Future Scope & IoT Hardware Integration</h3>
        </div>
        <p style={{ fontSize: "0.92rem", color: "var(--text-secondary)", marginBottom: "1.25rem", lineHeight: 1.6 }}>
          The backend service is engineered with a modular <code>ArduinoTelemetryService</code> interface ready for live hardware integration:
        </p>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "1rem", fontSize: "0.85rem" }}>
          <div style={{ padding: "0.85rem", backgroundColor: "var(--bg-input)", borderRadius: "var(--radius-sm)" }}>
            <strong style={{ color: "var(--solar-yellow)" }}>• Arduino / ESP32 Controller:</strong>
            <p style={{ color: "var(--text-muted)", marginTop: "0.25rem" }}>Microcontroller interfacing with pyranometers, DHT22, and DS18B20 contact temperature sensors.</p>
          </div>
          <div style={{ padding: "0.85rem", backgroundColor: "var(--bg-input)", borderRadius: "var(--radius-sm)" }}>
            <strong style={{ color: "var(--solar-green)" }}>• Real-time INA219 Telemetry:</strong>
            <p style={{ color: "var(--text-muted)", marginTop: "0.25rem" }}>Direct measurement of panel operating voltage (V) and string current (A) for ground-truth validation.</p>
          </div>
          <div style={{ padding: "0.85rem", backgroundColor: "var(--bg-input)", borderRadius: "var(--radius-sm)" }}>
            <strong style={{ color: "var(--solar-cyan)" }}>• Automated Sprinkler Trigger:</strong>
            <p style={{ color: "var(--text-muted)", marginTop: "0.25rem" }}>Relay trigger signal dispatched automatically when soiling exceeds High/Severe threshold (&gt;30%).</p>
          </div>
          <div style={{ padding: "0.85rem", backgroundColor: "var(--bg-input)", borderRadius: "var(--radius-sm)" }}>
            <strong style={{ color: "#c084fc" }}>• Cloud Edge Deployment:</strong>
            <p style={{ color: "var(--text-muted)", marginTop: "0.25rem" }}>Edge AI inference on NVIDIA Jetson or Raspberry Pi deployed directly on solar farm inverter stations.</p>
          </div>
        </div>
      </div>

      <div style={{ textAlign: "center", marginBottom: "1rem" }}>
        <Link to="/upload" className="btn btn-primary" style={{ padding: "0.85rem 2rem" }}>
          <span>Try Solar Panel Analysis</span>
          <ArrowRight size={18} />
        </Link>
      </div>
    </div>
  );
};
