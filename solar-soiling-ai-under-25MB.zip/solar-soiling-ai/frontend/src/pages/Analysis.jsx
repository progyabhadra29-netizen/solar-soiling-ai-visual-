import React, { useEffect, useState } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import api from "../services/api";
import { ProcessingSteps } from "../components/ProcessingSteps";
import { AlertCircle, RefreshCw, UploadCloud, ArrowRight, Cpu, Activity } from "lucide-react";

export const Analysis = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [error, setError] = useState("");

  const stateData = location.state;

  useEffect(() => {
    if (!stateData?.imageFile) {
      return;
    }

    let isMounted = true;

    const executePipeline = async () => {
      try {
        // Step 1: Image Uploaded
        if (isMounted) setCurrentStep(1);
        await new Promise((r) => setTimeout(r, 450));

        // Step 2: Image Preprocessing (Bilateral filter, CLAHE)
        if (isMounted) setCurrentStep(2);
        await new Promise((r) => setTimeout(r, 550));

        // Step 3: Swin Transformer V2 (Segmentation)
        if (isMounted) setCurrentStep(3);

        const formData = new FormData();
        formData.append("image", stateData.imageFile);
        formData.append("rated_power", stateData.ratedPower || 420);
        formData.append("irradiance", stateData.irradiance || 1000);
        formData.append("ambient_temp", stateData.ambientTemp || 25);

        // Call FastAPI Backend (Axios sends proper multipart with boundary)
        const response = await api.post("/api/analyze", formData);

        // Step 4: Soiling Percentage Calculation
        if (isMounted) setCurrentStep(4);
        await new Promise((r) => setTimeout(r, 450));

        // Step 5: Feature Preparation (Temporal operational window)
        if (isMounted) setCurrentStep(5);
        await new Promise((r) => setTimeout(r, 450));

        // Step 6: PatchTST (Power Loss Prediction)
        if (isMounted) setCurrentStep(6);
        await new Promise((r) => setTimeout(r, 450));

        // Step 7: Generating Performance Report
        if (isMounted) setCurrentStep(7);
        await new Promise((r) => setTimeout(r, 500));

        // Navigate to Results page with full model output
        if (isMounted) {
          navigate("/results", { state: { result: response.data } });
        }
      } catch (err) {
        console.error("Analysis execution error:", err);
        if (isMounted) {
          setError(
            err.response?.data?.detail ||
            err.message ||
            "Pipeline inference error. Please check your backend connection."
          );
        }
      }
    };

    executePipeline();

    return () => {
      isMounted = false;
    };
  }, [stateData, navigate]);

  // If active pipeline is running
  if (stateData?.imageFile) {
    return (
      <div className="page-wrapper" style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: "75vh" }}>
        <div style={{ textAlign: "center", marginBottom: "2rem" }}>
          <div className="badge badge-moderate" style={{ marginBottom: "0.5rem" }}>
            AI Pipeline Active
          </div>
          <h1 style={{ fontSize: "2rem", marginBottom: "0.5rem" }}>
            Analyzing Solar Panel Surface
          </h1>
          <p style={{ color: "var(--text-secondary)", fontSize: "1rem" }}>
            Executing Swin Transformer V2 soiling segmentation and PatchTST power loss estimation.
          </p>
        </div>

        {error ? (
          <div className="solar-card" style={{ maxWidth: "560px", width: "100%", padding: "2rem", textAlign: "center" }}>
            <div className="alert alert-danger" style={{ marginBottom: "1.5rem" }}>
              <AlertCircle size={20} />
              <span>{error}</span>
            </div>
            <Link to="/upload" className="btn btn-primary" style={{ margin: "0 auto" }}>
              <RefreshCw size={18} /> Return to Upload Page
            </Link>
          </div>
        ) : (
          <ProcessingSteps currentStep={currentStep} />
        )}
      </div>
    );
  }

  // If user navigated directly to /analysis without uploading an image
  return (
    <div className="page-wrapper" style={{ maxWidth: "750px", textAlign: "center", padding: "3rem 1.5rem" }}>
      <div className="solar-card" style={{ padding: "3rem 2rem", display: "flex", flexDirection: "column", alignItems: "center", gap: "1.5rem" }}>
        <div style={{
          width: "72px",
          height: "72px",
          borderRadius: "50%",
          backgroundColor: "rgba(246, 201, 14, 0.1)",
          border: "1px solid rgba(246, 201, 14, 0.3)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "var(--solar-yellow)"
        }}>
          <UploadCloud size={36} />
        </div>

        <div>
          <div className="badge badge-low" style={{ marginBottom: "0.75rem" }}>
            Step 4 of 6: AI Inference Pipeline
          </div>
          <h2 style={{ fontSize: "1.8rem", marginBottom: "0.5rem" }}>
            No Solar Panel Image Selected
          </h2>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.95rem", maxWidth: "520px", lineHeight: 1.6 }}>
            To run the <strong>Swin Transformer V2</strong> and <strong>PatchTST</strong> dual-model pipeline, please first upload or capture a solar panel image on the Upload page.
          </p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem", width: "100%", maxWidth: "500px", textAlign: "left", fontSize: "0.85rem" }}>
          <div style={{ padding: "0.85rem", backgroundColor: "var(--bg-input)", borderRadius: "var(--radius-sm)", border: "1px solid var(--border-color)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "0.35rem", fontWeight: 700, color: "var(--solar-yellow)" }}>
              <Cpu size={16} /> Swin Transformer V2
            </div>
            <p style={{ color: "var(--text-muted)", marginTop: "0.2rem" }}>Detects and segments solar panel surface dust coverage.</p>
          </div>
          <div style={{ padding: "0.85rem", backgroundColor: "var(--bg-input)", borderRadius: "var(--radius-sm)", border: "1px solid var(--border-color)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "0.35rem", fontWeight: 700, color: "var(--solar-green)" }}>
              <Activity size={16} /> PatchTST Model
            </div>
            <p style={{ color: "var(--text-muted)", marginTop: "0.2rem" }}>Predicts operational photovoltaic power generation loss.</p>
          </div>
        </div>

        <Link to="/upload" className="btn btn-primary" style={{ padding: "0.85rem 2rem", fontSize: "1rem", marginTop: "0.5rem" }}>
          <UploadCloud size={18} />
          <span>Go to Upload Page</span>
          <ArrowRight size={18} />
        </Link>
      </div>
    </div>
  );
};