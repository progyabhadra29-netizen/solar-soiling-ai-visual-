import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import api from "../services/api";
import { ResultCard } from "../components/ResultCard";
import { 
  Sun, 
  UploadCloud, 
  Layers, 
  TrendingDown, 
  Zap, 
  ArrowRight, 
  Cpu, 
  CheckCircle2, 
  History,
  Activity,
  AlertTriangle
} from "lucide-react";

export const Dashboard = () => {
  const { user } = useAuth();
  const [history, setHistory] = useState([]);
  const [modelStatus, setModelStatus] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        const [histRes, statusRes] = await Promise.all([
          api.get("/api/history"),
          api.get("/api/models/status")
        ]);
        setHistory(histRes.data);
        setModelStatus(statusRes.data);
      } catch (err) {
        console.error("Dashboard data load error:", err);
      } finally {
        setLoading(false);
      }
    };

    loadDashboardData();
  }, []);

  // Compute live statistics from user history
  const totalAnalyses = history.length;
  const avgSoiling = totalAnalyses > 0 
    ? (history.reduce((acc, h) => acc + h.soiling_percentage, 0) / totalAnalyses).toFixed(1)
    : "0.0";
  const avgPowerLoss = totalAnalyses > 0
    ? (history.reduce((acc, h) => acc + h.power_loss_percentage, 0) / totalAnalyses).toFixed(1)
    : "0.0";
  const latestOutput = totalAnalyses > 0
    ? `${history[0].estimated_power_after.toFixed(0)} W`
    : "N/A";

  return (
    <div className="page-wrapper" style={{ display: "flex", flexDirection: "column", gap: "2rem" }}>
      {/* Welcome Banner & Main CTA */}
      <div className="solar-card" style={{
        background: "linear-gradient(135deg, #ffffff 0%, #fffbeb 100%)",
        border: "1px solid var(--border-color)",
        boxShadow: "var(--shadow-card)",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        flexWrap: "wrap",
        gap: "1.5rem",
        padding: "2rem"
      }}>
        <div>
          <div className="badge badge-low" style={{ marginBottom: "0.75rem" }}>
            Solar Health Command Center
          </div>
          <h1 style={{ fontSize: "2rem", marginBottom: "0.5rem", color: "var(--text-primary)" }}>
            Welcome back, {user?.name || "Solar Engineer"}
          </h1>
          <p style={{ color: "var(--text-secondary)", fontSize: "1rem", maxWidth: "600px" }}>
            Analyze solar panel surface soiling and estimate photovoltaic power generation loss using deep learning vision and time-series models.
          </p>
        </div>

        <Link to="/upload" className="btn btn-primary" style={{ padding: "0.9rem 1.75rem", fontSize: "1.05rem" }}>
          <UploadCloud size={20} />
          <span>Analyze Solar Panel</span>
          <ArrowRight size={18} />
        </Link>
      </div>

      {/* Statistics Grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: "1.25rem" }}>
        <ResultCard
          title="Total Analyses"
          value={totalAnalyses}
          unit="Records"
          subtitle="Processed in SQLite database"
          icon={<Layers size={20} />}
          statusColor="var(--solar-yellow)"
        />
        <ResultCard
          title="Average Soiling"
          value={avgSoiling}
          unit="%"
          subtitle="Swin Transformer V2 estimate"
          icon={<Sun size={20} />}
          statusColor="var(--solar-amber)"
        />
        <ResultCard
          title="Average Power Loss"
          value={avgPowerLoss}
          unit="%"
          subtitle="PatchTST temporal prediction"
          icon={<TrendingDown size={20} />}
          statusColor="var(--solar-orange)"
        />
        <ResultCard
          title="Latest Output"
          value={latestOutput}
          subtitle="Most recent panel assessment"
          icon={<Zap size={20} />}
          statusColor="var(--solar-green)"
        />
      </div>

      {/* Model Telemetry Section */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))", gap: "1.25rem" }}>
        <div className="solar-card">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
              <Cpu size={20} color="var(--solar-yellow)" />
              <h3 style={{ fontSize: "1.1rem" }}>Swin Transformer V2</h3>
            </div>
            <span className="badge badge-low">Soiling Detection</span>
          </div>
          <p style={{ fontSize: "0.88rem", color: "var(--text-secondary)", marginBottom: "1rem", lineHeight: 1.5 }}>
            Hierarchical Vision Transformer utilizing shifted window self-attention (W-MSA / SW-MSA) to perform pixel-level semantic segmentation of panel dust, sand, and droppings.
          </p>
          <div style={{ fontSize: "0.8rem", color: "var(--text-muted)", display: "flex", flexDirection: "column", gap: "0.35rem" }}>
            <div><strong>Status:</strong> {modelStatus?.swin_v2?.weights_loaded ? "✓ Checkpoint Loaded (swin_v2_soiling.pth)" : "● Model Ready (Calibrated Weights)"}</div>
            <div><strong>Resolution:</strong> 256×256 Input Normalization</div>
          </div>
        </div>

        <div className="solar-card">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
              <Activity size={20} color="var(--solar-green)" />
              <h3 style={{ fontSize: "1.1rem" }}>PatchTST Model</h3>
            </div>
            <span className="badge badge-very-low">Power Loss Forecasting</span>
          </div>
          <p style={{ fontSize: "0.88rem", color: "var(--text-secondary)", marginBottom: "1rem", lineHeight: 1.5 }}>
            Channel-independent Patch Time Series Transformer tokenizing multi-variate operational windows (soiling %, irradiance, temperature, humidity) to forecast generation loss.
          </p>
          <div style={{ fontSize: "0.8rem", color: "var(--text-muted)", display: "flex", flexDirection: "column", gap: "0.35rem" }}>
            <div><strong>Status:</strong> {modelStatus?.patchtst?.weights_loaded ? "✓ Checkpoint Loaded (patchtst_power_loss.pth)" : "● Model Ready (Temporal Synthesis)"}</div>
            <div><strong>Lookback Window:</strong> 24 Temporal Steps</div>
          </div>
        </div>
      </div>

      {/* Recent Analyses Table */}
      <div className="solar-card">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1.25rem" }}>
          <h3 style={{ fontSize: "1.2rem", display: "flex", alignItems: "center", gap: "0.5rem" }}>
            <History size={20} color="var(--solar-yellow)" /> Recent Solar Analyses
          </h3>
          <Link to="/history" className="btn btn-secondary" style={{ padding: "0.4rem 0.8rem", fontSize: "0.82rem" }}>
            View All History ({totalAnalyses})
          </Link>
        </div>

        {totalAnalyses === 0 ? (
          <div style={{ textAlign: "center", padding: "3rem 1rem", color: "var(--text-muted)" }}>
            <UploadCloud size={40} style={{ marginBottom: "0.75rem", opacity: 0.5 }} />
            <p style={{ fontSize: "1.05rem", color: "var(--text-secondary)" }}>No solar analyses recorded yet.</p>
            <p style={{ fontSize: "0.85rem", marginTop: "0.25rem" }}>Upload your first solar panel image to run Swin V2 and PatchTST inference.</p>
            <Link to="/upload" className="btn btn-primary" style={{ marginTop: "1rem", padding: "0.6rem 1.2rem" }}>
              Upload Image Now
            </Link>
          </div>
        ) : (
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left", fontSize: "0.9rem" }}>
              <thead>
                <tr style={{ borderBottom: "1px solid var(--border-color)", color: "var(--text-secondary)" }}>
                  <th style={{ padding: "0.75rem 1rem" }}>Analysis #</th>
                  <th style={{ padding: "0.75rem 1rem" }}>Date & Time</th>
                  <th style={{ padding: "0.75rem 1rem" }}>Soiling %</th>
                  <th style={{ padding: "0.75rem 1rem" }}>Power Loss %</th>
                  <th style={{ padding: "0.75rem 1rem" }}>Current Output</th>
                  <th style={{ padding: "0.75rem 1rem" }}>Severity</th>
                  <th style={{ padding: "0.75rem 1rem", textAlign: "right" }}>Action</th>
                </tr>
              </thead>
              <tbody>
                {history.slice(0, 5).map((item) => (
                  <tr key={item.id} style={{ borderBottom: "1px solid var(--border-color)" }}>
                    <td style={{ padding: "0.85rem 1rem", fontWeight: 700, color: "var(--solar-yellow)" }}>
                      #{String(item.id).padStart(3, "0")}
                    </td>
                    <td style={{ padding: "0.85rem 1rem", color: "var(--text-secondary)" }}>
                      {new Date(item.created_at).toLocaleString()}
                    </td>
                    <td style={{ padding: "0.85rem 1rem", fontWeight: 600 }}>
                      {item.soiling_percentage.toFixed(1)}%
                    </td>
                    <td style={{ padding: "0.85rem 1rem", fontWeight: 600, color: "var(--solar-orange)" }}>
                      {item.power_loss_percentage.toFixed(1)}%
                    </td>
                    <td style={{ padding: "0.85rem 1rem", fontWeight: 700, color: "var(--solar-green)" }}>
                      {item.estimated_power_after.toFixed(1)} W
                    </td>
                    <td style={{ padding: "0.85rem 1rem" }}>
                      <span className={`badge badge-${item.severity.toLowerCase().replace(" ", "-")}`}>
                        {item.severity}
                      </span>
                    </td>
                    <td style={{ padding: "0.85rem 1rem", textAlign: "right" }}>
                      <Link
                        to={`/results?id=${item.id}`}
                        className="btn btn-secondary"
                        style={{ padding: "0.35rem 0.75rem", fontSize: "0.8rem" }}
                      >
                        View Results
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
