import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../services/api";
import { 
  History as HistoryIcon, 
  Trash2, 
  ExternalLink, 
  Search, 
  Filter, 
  Calendar, 
  Zap, 
  Sun, 
  Layers,
  AlertCircle
} from "lucide-react";

export const History = () => {
  const [history, setHistory] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSeverity, setSelectedSeverity] = useState("ALL");
  const [error, setError] = useState("");

  const loadHistory = async () => {
    try {
      setLoading(true);
      const res = await api.get("/api/history");
      setHistory(res.data);
      setFiltered(res.data);
    } catch (err) {
      setError("Failed to load analysis history.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadHistory();
  }, []);

  // Filter effect
  useEffect(() => {
    let list = [...history];

    if (selectedSeverity !== "ALL") {
      list = list.filter((item) => item.severity.toUpperCase() === selectedSeverity);
    }

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      list = list.filter(
        (item) =>
          String(item.id).includes(q) ||
          item.severity.toLowerCase().includes(q) ||
          item.model_status.toLowerCase().includes(q)
      );
    }

    setFiltered(list);
  }, [searchTerm, selectedSeverity, history]);

  const handleDelete = async (id) => {
    if (!window.confirm(`Delete analysis record #${id}?`)) return;
    try {
      await api.delete(`/api/history/${id}`);
      setHistory((prev) => prev.filter((item) => item.id !== id));
    } catch (err) {
      alert("Failed to delete record.");
    }
  };

  return (
    <div className="page-wrapper" style={{ display: "flex", flexDirection: "column", gap: "2rem" }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "1rem" }}>
        <div>
          <div className="badge badge-low" style={{ marginBottom: "0.4rem" }}>
            SQLite Database Records
          </div>
          <h1 style={{ fontSize: "2rem" }}>Solar Analysis History</h1>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.95rem" }}>
            All historical solar panel soiling assessments and power loss calculations for your account.
          </p>
        </div>

        <Link to="/upload" className="btn btn-primary">
          <Sun size={18} /> New Analysis
        </Link>
      </div>

      {/* Filter and Search Bar */}
      <div className="solar-card" style={{ display: "flex", gap: "1rem", flexWrap: "wrap", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", flex: 1, minWidth: "240px", position: "relative" }}>
          <Search size={18} color="var(--text-muted)" style={{ position: "absolute", left: "0.9rem" }} />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by analysis ID or severity..."
            className="form-control"
            style={{ paddingLeft: "2.6rem" }}
          />
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
          <Filter size={16} color="var(--text-muted)" />
          <span style={{ fontSize: "0.85rem", color: "var(--text-secondary)" }}>Severity:</span>
          <select
            value={selectedSeverity}
            onChange={(e) => setSelectedSeverity(e.target.value)}
            className="form-control"
            style={{ width: "auto", padding: "0.6rem 1rem" }}
          >
            <option value="ALL">All Severities</option>
            <option value="VERY LOW">Very Low</option>
            <option value="LOW">Low</option>
            <option value="MODERATE">Moderate</option>
            <option value="HIGH">High</option>
            <option value="SEVERE">Severe</option>
          </select>
        </div>
      </div>

      {/* Content */}
      {loading ? (
        <div style={{ textAlign: "center", padding: "3rem" }}>
          <div className="spin-animation" style={{ fontSize: "2rem", color: "var(--solar-yellow)" }}>☀</div>
          <p style={{ marginTop: "0.5rem" }}>Loading history...</p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="solar-card" style={{ textAlign: "center", padding: "3.5rem 1rem", color: "var(--text-muted)" }}>
          <HistoryIcon size={48} style={{ opacity: 0.4, marginBottom: "1rem" }} />
          <h3 style={{ fontSize: "1.2rem", color: "var(--text-primary)", marginBottom: "0.5rem" }}>No Records Found</h3>
          <p style={{ fontSize: "0.9rem", maxWidth: "400px", margin: "0 auto 1.5rem" }}>
            {history.length === 0
              ? "You have not performed any solar panel analyses yet."
              : "No records match your search filter."}
          </p>
          {history.length === 0 && (
            <Link to="/upload" className="btn btn-primary">
              Analyze Solar Panel Now
            </Link>
          )}
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: "1.25rem" }}>
          {filtered.map((item) => (
            <div key={item.id} className="solar-card" style={{ display: "flex", flexDirection: "column", justifyContent: "space-between", gap: "1rem" }}>
              {/* Card Header */}
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <div>
                  <span style={{ fontSize: "1.1rem", fontWeight: 800, color: "var(--solar-yellow)", fontFamily: "var(--font-heading)" }}>
                    Analysis #{String(item.id).padStart(3, "0")}
                  </span>
                  <div style={{ display: "flex", alignItems: "center", gap: "0.35rem", fontSize: "0.75rem", color: "var(--text-muted)", marginTop: "2px" }}>
                    <Calendar size={13} />
                    {new Date(item.created_at).toLocaleString()}
                  </div>
                </div>

                <span className={`badge badge-${item.severity.toLowerCase().replace(" ", "-")}`}>
                  {item.severity}
                </span>
              </div>

              {/* Thumbnail Overlay Preview */}
              <div style={{
                height: "150px",
                borderRadius: "var(--radius-sm)",
                overflow: "hidden",
                border: "1px solid var(--border-color)",
                position: "relative"
              }}>
                <img
                  src={item.overlay_image_path}
                  alt={`Analysis #${item.id}`}
                  style={{ width: "100%", height: "100%", objectFit: "cover" }}
                />
              </div>

              {/* Key Metrics */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.75rem", padding: "0.75rem", backgroundColor: "var(--bg-input)", borderRadius: "var(--radius-sm)" }}>
                <div>
                  <span style={{ fontSize: "0.7rem", color: "var(--text-muted)", textTransform: "uppercase" }}>Soiling %</span>
                  <div style={{ fontSize: "1.15rem", fontWeight: 700, color: "var(--solar-yellow)" }}>
                    {item.soiling_percentage.toFixed(1)}%
                  </div>
                </div>
                <div>
                  <span style={{ fontSize: "0.7rem", color: "var(--text-muted)", textTransform: "uppercase" }}>Power Loss %</span>
                  <div style={{ fontSize: "1.15rem", fontWeight: 700, color: "var(--solar-orange)" }}>
                    {item.power_loss_percentage.toFixed(1)}%
                  </div>
                </div>
                <div>
                  <span style={{ fontSize: "0.7rem", color: "var(--text-muted)", textTransform: "uppercase" }}>Rated Power</span>
                  <div style={{ fontSize: "0.95rem", fontWeight: 600 }}>
                    {item.rated_power} W
                  </div>
                </div>
                <div>
                  <span style={{ fontSize: "0.7rem", color: "var(--text-muted)", textTransform: "uppercase" }}>Estimated Output</span>
                  <div style={{ fontSize: "0.95rem", fontWeight: 600, color: "var(--solar-green)" }}>
                    {item.estimated_power_after.toFixed(1)} W
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div style={{ display: "flex", gap: "0.75rem", justifyContent: "space-between", borderTop: "1px solid var(--border-color)", paddingTop: "0.75rem" }}>
                <button
                  onClick={() => handleDelete(item.id)}
                  title="Delete record"
                  style={{ background: "transparent", border: "none", color: "#f87171", cursor: "pointer", display: "flex", alignItems: "center", gap: "0.3rem", fontSize: "0.8rem" }}
                >
                  <Trash2 size={15} /> Delete
                </button>

                <Link
                  to={`/results?id=${item.id}`}
                  className="btn btn-primary"
                  style={{ padding: "0.45rem 0.9rem", fontSize: "0.82rem" }}
                >
                  <span>View Results</span>
                  <ExternalLink size={14} />
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
