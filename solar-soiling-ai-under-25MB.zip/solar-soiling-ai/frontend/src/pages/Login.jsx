import React, { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { Sun, Lock, Mail, ArrowRight, AlertCircle, ShieldCheck } from "lucide-react";

export const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const from = location.state?.from?.pathname || "/dashboard";

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      await login(email, password, rememberMe);
      navigate(from, { replace: true });
    } catch (err) {
      setError(err.response?.data?.detail || "Invalid email or password. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: "100vh",
      display: "flex",
      backgroundColor: "var(--bg-main)",
      backgroundImage: "radial-gradient(circle at 80% 20%, rgba(246, 201, 14, 0.08) 0%, transparent 45%)"
    }}>
      {/* Left Hero Section (Solar Branding) */}
      <div style={{
        flex: 1,
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        padding: "3.5rem",
        borderRight: "1px solid var(--border-color)",
        backgroundColor: "#ffffff",
        position: "relative"
      }} className="auth-hero">
        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
          <div style={{
            width: "44px",
            height: "44px",
            borderRadius: "12px",
            background: "linear-gradient(135deg, #f6c90e, #d97706)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            boxShadow: "0 0 20px rgba(246, 201, 14, 0.4)"
          }}>
            <Sun size={26} color="#070d1e" />
          </div>
          <div>
            <h2 style={{ fontSize: "1.3rem", fontWeight: 800 }}>Solar AI</h2>
            <span style={{ fontSize: "0.75rem", color: "var(--solar-yellow)", textTransform: "uppercase", letterSpacing: "0.08em" }}>
              Renewable Intelligence
            </span>
          </div>
        </div>

        <div style={{ maxWidth: "520px" }}>
          <div className="badge badge-moderate" style={{ marginBottom: "1.25rem" }}>
            Deep Learning PV Monitoring
          </div>
          <h1 style={{ fontSize: "2.6rem", fontWeight: 800, lineHeight: 1.15, marginBottom: "1.25rem" }}>
            AI-Based Solar Panel Soiling Detection & Power Loss Prediction
          </h1>
          <p style={{ fontSize: "1.05rem", color: "var(--text-secondary)", lineHeight: 1.6, marginBottom: "2rem" }}>
            Automate dust accumulation analysis with <strong>Swin Transformer V2</strong> segmentation and forecast operational energy reduction with <strong>PatchTST</strong> time-series modeling.
          </p>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
            <div style={{ padding: "1rem", backgroundColor: "#f8fafc", borderRadius: "var(--radius-sm)", border: "1px solid var(--border-color)" }}>
              <div style={{ fontWeight: 700, color: "var(--solar-yellow)", fontSize: "1.1rem" }}>Swin V2</div>
              <div style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>Shifted-Window Vision Transformer for precision soiling masks</div>
            </div>
            <div style={{ padding: "1rem", backgroundColor: "#f8fafc", borderRadius: "var(--radius-sm)", border: "1px solid var(--border-color)" }}>
              <div style={{ fontWeight: 700, color: "var(--solar-green)", fontSize: "1.1rem" }}>PatchTST</div>
              <div style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>Patch-based channel-independent temporal power loss forecasting</div>
            </div>
          </div>
        </div>

        <div style={{ fontSize: "0.8rem", color: "var(--text-muted)", display: "flex", alignItems: "center", gap: "0.5rem" }}>
          <ShieldCheck size={16} color="var(--solar-green)" />
          Secured with JWT authentication & SQLite per-user encrypted storage.
        </div>
      </div>

      {/* Right Login Form */}
      <div style={{
        flex: 1,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "2.5rem"
      }}>
        <div className="solar-card" style={{ maxWidth: "440px", width: "100%", padding: "2.5rem" }}>
          <div style={{ marginBottom: "2rem" }}>
            <h2 style={{ fontSize: "1.8rem", marginBottom: "0.4rem" }}>Engineer Login</h2>
            <p style={{ fontSize: "0.9rem", color: "var(--text-secondary)" }}>
              Sign in to access your solar diagnostics dashboard.
            </p>
          </div>

          {error && (
            <div className="alert alert-danger">
              <AlertCircle size={18} />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Email Address</label>
              <div style={{ position: "relative" }}>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="engineer@solar.ai"
                  className="form-control"
                  style={{ paddingLeft: "2.6rem" }}
                />
                <Mail size={18} color="var(--text-muted)" style={{ position: "absolute", left: "0.9rem", top: "50%", transform: "translateY(-50%)" }} />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Password</label>
              <div style={{ position: "relative" }}>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="form-control"
                  style={{ paddingLeft: "2.6rem" }}
                />
                <Lock size={18} color="var(--text-muted)" style={{ position: "absolute", left: "0.9rem", top: "50%", transform: "translateY(-50%)" }} />
              </div>
            </div>

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1.5rem", fontSize: "0.85rem" }}>
              <label style={{ display: "flex", alignItems: "center", gap: "0.4rem", cursor: "pointer", color: "var(--text-secondary)" }}>
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  style={{ accentColor: "var(--solar-yellow)" }}
                />
                Remember me
              </label>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn btn-primary btn-block"
              style={{ padding: "0.9rem" }}
            >
              {loading ? (
                <span>Signing in...</span>
              ) : (
                <>
                  <span>Login to System</span>
                  <ArrowRight size={18} />
                </>
              )}
            </button>
          </form>

          <div style={{ textAlign: "center", marginTop: "1.75rem", fontSize: "0.9rem", color: "var(--text-secondary)" }}>
            Don't have an account?{" "}
            <Link to="/signup" style={{ fontWeight: 700, color: "var(--solar-yellow)" }}>
              Sign Up
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
