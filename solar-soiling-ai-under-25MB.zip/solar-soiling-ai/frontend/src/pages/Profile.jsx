import React, { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import api from "../services/api";
import { User, Mail, Calendar, Layers, LogOut, ShieldCheck, Sun, ArrowRight } from "lucide-react";

export const Profile = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [historyCount, setHistoryCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await api.get("/api/history");
        setHistoryCount(res.data.length);
      } catch (err) {
        // pass
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  return (
    <div className="page-wrapper" style={{ maxWidth: "700px" }}>
      <div style={{ marginBottom: "2rem" }}>
        <div className="badge badge-low" style={{ marginBottom: "0.5rem" }}>
          Account & Engineer Settings
        </div>
        <h1 style={{ fontSize: "2rem", marginBottom: "0.5rem" }}>User Profile</h1>
        <p style={{ color: "var(--text-secondary)" }}>
          Manage your Solar AI monitoring account credentials and view your activity summary.
        </p>
      </div>

      <div className="solar-card" style={{ display: "flex", flexDirection: "column", gap: "2rem", padding: "2.5rem" }}>
        {/* User Avatar & Name Banner */}
        <div style={{ display: "flex", alignItems: "center", gap: "1.5rem", borderBottom: "1px solid var(--border-color)", paddingBottom: "2rem" }}>
          <div style={{
            width: "72px",
            height: "72px",
            borderRadius: "50%",
            background: "linear-gradient(135deg, #f6c90e, #d97706)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "2rem",
            fontWeight: 800,
            color: "#070d1e",
            boxShadow: "0 0 25px rgba(246, 201, 14, 0.4)"
          }}>
            {user?.name ? user.name.charAt(0).toUpperCase() : "U"}
          </div>

          <div>
            <h2 style={{ fontSize: "1.5rem", marginBottom: "0.25rem" }}>{user?.name || "Solar Engineer"}</h2>
            <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", color: "var(--text-secondary)", fontSize: "0.9rem" }}>
              <Mail size={16} />
              <span>{user?.email}</span>
            </div>
          </div>
        </div>

        {/* Profile Details List */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1.5rem" }}>
          <div style={{ padding: "1.25rem", backgroundColor: "var(--bg-input)", borderRadius: "var(--radius-sm)" }}>
            <span style={{ fontSize: "0.75rem", color: "var(--text-muted)", textTransform: "uppercase", display: "block", marginBottom: "0.25rem" }}>
              Total Completed Analyses
            </span>
            <div style={{ fontSize: "1.6rem", fontWeight: 800, color: "var(--solar-yellow)", fontFamily: "var(--font-heading)" }}>
              {historyCount} Records
            </div>
          </div>

          <div style={{ padding: "1.25rem", backgroundColor: "var(--bg-input)", borderRadius: "var(--radius-sm)" }}>
            <span style={{ fontSize: "0.75rem", color: "var(--text-muted)", textTransform: "uppercase", display: "block", marginBottom: "0.25rem" }}>
              Account Role
            </span>
            <div style={{ fontSize: "1.2rem", fontWeight: 700, color: "var(--solar-green)", display: "flex", alignItems: "center", gap: "0.4rem", marginTop: "0.25rem" }}>
              <ShieldCheck size={20} /> Solar Project Engineer
            </div>
          </div>
        </div>

        {/* Actions */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderTop: "1px solid var(--border-color)", paddingTop: "1.75rem" }}>
          <Link to="/history" className="btn btn-secondary">
            <Layers size={16} /> View Analysis History
          </Link>

          <button onClick={handleLogout} className="btn btn-danger">
            <LogOut size={16} />
            <span>Logout from System</span>
          </button>
        </div>
      </div>
    </div>
  );
};
