import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { UploadBox } from "../components/UploadBox";
import { Sun, Sparkles, Sliders, AlertCircle, ArrowRight } from "lucide-react";

export const Upload = () => {
  const [imageFile, setImageFile] = useState(null);
  const [ratedPower, setRatedPower] = useState(420);
  const [irradiance, setIrradiance] = useState(1000);
  const [ambientTemp, setAmbientTemp] = useState(25);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [error, setError] = useState("");

  const navigate = useNavigate();

  const handleStartAnalysis = () => {
    if (!imageFile) {
      setError("Please upload or capture a solar panel image before analyzing.");
      return;
    }

    if (ratedPower <= 0) {
      setError("Please enter a valid rated power rating (W).");
      return;
    }

    // Pass data via navigation state to Analysis page
    navigate("/analysis", {
      state: {
        imageFile,
        ratedPower,
        irradiance,
        ambientTemp
      }
    });
  };

  return (
    <div className="page-wrapper" style={{ maxWidth: "860px" }}>
      <div style={{ marginBottom: "2rem", textAlign: "center" }}>
        <div className="badge badge-low" style={{ marginBottom: "0.5rem" }}>
          Inference Input Configuration
        </div>
        <h1 style={{ fontSize: "2.2rem", marginBottom: "0.5rem" }}>
          Upload Solar Panel Image
        </h1>
        <p style={{ color: "var(--text-secondary)", fontSize: "1.05rem" }}>
          Upload a clear image of your solar panel for AI-powered soiling analysis and operational power loss prediction.
        </p>
      </div>

      {error && (
        <div className="alert alert-danger" style={{ marginBottom: "1.5rem" }}>
          <AlertCircle size={18} />
          <span>{error}</span>
        </div>
      )}

      {/* Main Upload Box */}
      <UploadBox
        onImageSelect={(file) => {
          setImageFile(file);
          setError("");
        }}
        selectedImage={imageFile}
        ratedPower={ratedPower}
        setRatedPower={setRatedPower}
      />

      {/* Advanced Environmental Parameter Accordion */}
      <div className="solar-card" style={{ marginTop: "1.5rem" }}>
        <button
          type="button"
          onClick={() => setShowAdvanced(!showAdvanced)}
          style={{
            background: "transparent",
            border: "none",
            color: "var(--text-secondary)",
            fontSize: "0.92rem",
            fontWeight: 600,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            width: "100%",
            cursor: "pointer",
            fontFamily: "var(--font-main)"
          }}
        >
          <span style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
            <Sliders size={18} color="var(--solar-yellow)" /> Optional Environmental / Weather Tuning
          </span>
          <span>{showAdvanced ? "▲ Hide" : "▼ Show Parameters"}</span>
        </button>

        {showAdvanced && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1.25rem", marginTop: "1.25rem", paddingTop: "1.25rem", borderTop: "1px solid var(--border-color)" }}>
            <div className="form-group">
              <label className="form-label">Solar Irradiance (G)</label>
              <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                <input
                  type="number"
                  min="100"
                  max="1400"
                  value={irradiance}
                  onChange={(e) => setIrradiance(Number(e.target.value))}
                  className="form-control"
                />
                <span style={{ fontSize: "0.85rem", color: "var(--text-muted)", whiteSpace: "nowrap" }}>W/m² (STC: 1000)</span>
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Ambient Temperature</label>
              <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                <input
                  type="number"
                  min="-10"
                  max="65"
                  value={ambientTemp}
                  onChange={(e) => setAmbientTemp(Number(e.target.value))}
                  className="form-control"
                />
                <span style={{ fontSize: "0.85rem", color: "var(--text-muted)", whiteSpace: "nowrap" }}>°C (STC: 25)</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* CTA Button */}
      <div style={{ marginTop: "2rem", display: "flex", justifyContent: "flex-end" }}>
        <button
          onClick={handleStartAnalysis}
          disabled={!imageFile}
          className="btn btn-primary"
          style={{ padding: "0.95rem 2rem", fontSize: "1.05rem" }}
        >
          <Sparkles size={20} />
          <span>Analyze Solar Panel</span>
          <ArrowRight size={18} />
        </button>
      </div>
    </div>
  );
};
