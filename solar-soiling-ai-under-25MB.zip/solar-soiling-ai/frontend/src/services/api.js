import axios from "axios";

const api = axios.create({
  baseURL: ""
});

// Request interceptor to attach JWT Authorization token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("solar_auth_token");
    if (token) {
      config.headers["Authorization"] = `Bearer ${token}`;
    }
    // If sending FormData, do not set application/json; let browser set multipart boundary
    if (config.data instanceof FormData) {
      delete config.headers["Content-Type"];
    } else if (!config.headers["Content-Type"]) {
      config.headers["Content-Type"] = "application/json";
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor to handle 401 Unauthorized
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("solar_auth_token");
      localStorage.removeItem("solar_user");
      if (!window.location.pathname.includes("/login") && !window.location.pathname.includes("/signup")) {
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);

export default api;