import api from "./api";

export const authService = {
  async signup(name, email, password) {
    const response = await api.post("/api/auth/signup", {
      name,
      email,
      password
    });
    return response.data;
  },

  async login(email, password, rememberMe = false) {
    const response = await api.post("/api/auth/login", {
      email,
      password,
      remember_me: rememberMe
    });
    if (response.data.access_token) {
      localStorage.setItem("solar_auth_token", response.data.access_token);
      localStorage.setItem("solar_user", JSON.stringify(response.data.user));
    }
    return response.data;
  },

  async getMe() {
    const response = await api.get("/api/auth/me");
    return response.data;
  },

  async logout() {
    try {
      await api.post("/api/auth/logout");
    } catch (e) {
      // ignore network failure on logout
    } finally {
      localStorage.removeItem("solar_auth_token");
      localStorage.removeItem("solar_user");
    }
  },

  getCurrentUser() {
    const userStr = localStorage.getItem("solar_user");
    if (userStr) {
      try {
        return JSON.parse(userStr);
      } catch (e) {
        return null;
      }
    }
    return null;
  },

  getToken() {
    return localStorage.getItem("solar_auth_token");
  },

  isAuthenticated() {
    return !!localStorage.getItem("solar_auth_token");
  }
};
